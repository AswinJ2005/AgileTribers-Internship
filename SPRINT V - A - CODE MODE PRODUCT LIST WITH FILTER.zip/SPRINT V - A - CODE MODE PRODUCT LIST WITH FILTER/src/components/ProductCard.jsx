import React from 'react';

function ProductCard({ product }) {
  
  const categoryClass = `category-${product.category.toLowerCase()}`;
  const highlightClass = product.rating > 4.5 ? 'highlight' : '';
  const outOfStockClass = product.stock === 0 ? 'out-of-stock-card' : '';

  return (
    <div className={`product-card ${categoryClass} ${highlightClass} ${outOfStockClass}`}>
      {product.stock === 0 && <span className="stock-badge">Out of Stock</span>}
      <div className="product-details">
        <h3 className="product-title">{product.title}</h3>
        {/* Changed from $ to the Indian Rupee symbol ₹ */}
        <p className="product-price">₹{product.price.toFixed(2)}</p>
        <p className="product-category">Category: {product.category}</p>
        <p className="product-rating">Rating: {product.rating} / 5 {product.rating > 4.5 && '⭐'}</p>
      </div>
    </div>
  );
}

export default ProductCard;
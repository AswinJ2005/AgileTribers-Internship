// src/components/FilterMenu.jsx

import React from 'react';

function FilterMenu({ categories, selectedCategory, onSelectCategory, products }) {
  
  // Bonus: Calculate product count for each category
  const getCategoryCount = (category) => {
    if (category === 'All') return products.length;
    return products.filter(p => p.category === category).length;
  };

  return (
    <div className="filter-menu">
      {categories.map(category => (
        <button
          key={category}
          className={`filter-button ${selectedCategory === category ? 'active' : ''}`}
          onClick={() => onSelectCategory(category)}
        >
          {category} 
          <span className="product-count">({getCategoryCount(category)})</span>
        </button>
      ))}
    </div>
  );
}

export default FilterMenu;
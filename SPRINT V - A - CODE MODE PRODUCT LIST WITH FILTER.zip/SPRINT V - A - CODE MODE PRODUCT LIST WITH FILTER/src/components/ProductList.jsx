import React from 'react';
import ProductCard from './ProductCard';

function ProductList({ products, selectedCategory }) {
  
  const filteredProducts = products.filter(product => {
    if (selectedCategory === 'All') {
      return true;
    }
    return product.category === selectedCategory;
  });

  if (filteredProducts.length === 0) {
    return <p className="fallback-message">No products found in this category.</p>;
  }

  return (
    <div className="product-list">
      {filteredProducts.map(product => (
        <ProductCard key={product.id} product={product} />
      ))}
    </div>
  );
}

export default ProductList;
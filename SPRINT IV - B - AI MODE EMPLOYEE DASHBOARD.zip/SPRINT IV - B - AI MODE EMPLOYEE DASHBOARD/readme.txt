Employee Management Dashboard 📊

A dynamic and interactive web dashboard for managing employee data, built with vanilla HTML, CSS, and JavaScript.

✨ Features

Add New Employees ➕: Easily add new employees to the list via a simple form.

Delete Employees 🗑️: Remove employees with a single click.

Filter by Department 🏢: View employees from a specific department.

Search by Name 🔍: Instantly find employees by typing their name.

Sort by Name & Salary ↕️: Click table headers to sort the data.

Calculate Average Salary 💰: Get the average salary of all employees.

Export Data to CSV 📄: Download the currently displayed employee list as a CSV file.

Light/Dark Mode Toggle ☀️/🌙: Switch between light and dark themes for comfortable viewing.

Fully Responsive Design 📱: Looks great on desktops, tablets, and phones.

🛠️ Technologies Used

HTML

CSS

JavaScript

🚀 How to Use

Download the index.html, style.css, and script.js files.

Place them all in the same folder.

Open the index.html file in your favorite web browser.

That's it! You're ready to manage your employees. 🎉
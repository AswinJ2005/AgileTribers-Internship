document.addEventListener('DOMContentLoaded', () => {

    // 1. Functionality: Create employee data
    let employees = [
        { id: 1, name: 'Alice Johnson', age: 32, department: 'Engineering', role: 'Software Engineer', salary: 95000 },
        { id: 2, name: 'Bob Smith', age: 28, department: 'Marketing', role: 'Marketing Specialist', salary: 65000 },
        { id: 3, name: 'Charlie Brown', age: 45, department: 'HR', role: 'HR Manager', salary: 105000 },
        { id: 4, name: 'Diana Prince', age: 38, department: 'Engineering', role: 'Project Manager', salary: 115000 },
        { id: 5, name: 'Ethan Hunt', age: 30, department: 'Sales', role: 'Sales Representative', salary: 75000 },
        { id: 6, name: 'Fiona Glenanne', age: 35, department: 'Marketing', role: 'Content Strategist', salary: 72000 },
        { id: 7, name: 'George Costanza', age: 41, department: 'Sales', role: 'Sales Manager', salary: 110000 },
        { id: 8, name: 'Hannah Montana', age: 26, department: 'Engineering', role: 'UI/UX Designer', salary: 85000 },
    ];
    let displayedEmployees = [...employees]; // Array for current view (sorting/filtering)
    let sortState = { key: null, order: 'asc' }; // New: State for sorting

    // Get references to DOM elements
    const employeeTableBody = document.getElementById('employeeTableBody');
    const departmentFilter = document.getElementById('departmentFilter');
    const searchInput = document.getElementById('searchInput');
    const toUpperCaseBtn = document.getElementById('toUpperCaseBtn');
    const avgSalaryBtn = document.getElementById('avgSalaryBtn');
    const avgSalaryResult = document.getElementById('avgSalaryResult');
    const searchedEmployeeResult = document.getElementById('searchedEmployeeResult');
    const employeeCount = document.getElementById('employeeCount');
    // New element references
    const addEmployeeForm = document.getElementById('addEmployeeForm');
    const exportCsvBtn = document.getElementById('exportCsvBtn');
    const themeToggleBtn = document.getElementById('themeToggleBtn');
    
    // ----- Core Modular Function to Render Table -----

    const renderTable = (employeeArray) => {
        employeeTableBody.innerHTML = ''; // Clear existing table rows
        displayedEmployees = employeeArray; // Update the currently displayed employees

        employeeArray.forEach(emp => {
            const row = document.createElement('tr');
            // New Feature: Added delete button with data-id attribute
            row.innerHTML = `
                <td>${emp.name}</td>
                <td>${emp.age}</td>
                <td>${emp.department}</td>
                <td>${emp.role}</td>
                <td>$${emp.salary.toLocaleString()}</td>
                <td>
                    <button class="delete-btn" data-id="${emp.id}">Delete</button>
                </td>
            `;
            employeeTableBody.appendChild(row);
        });
        
        employeeCount.textContent = employeeArray.length;
    };


    // ----- Main Function to Update Display (Filter & Sort) -----
    // This central function applies all filters and sorting, then renders the table
    const updateDisplay = () => {
        let filteredEmployees = [...employees];

        // Apply department filter
        const selectedDepartment = departmentFilter.value;
        if (selectedDepartment !== 'all') {
            filteredEmployees = filteredEmployees.filter(emp => emp.department === selectedDepartment);
        }

        // Apply search filter
        const searchTerm = searchInput.value.toLowerCase().trim();
        if (searchTerm) {
            filteredEmployees = filteredEmployees.filter(emp => emp.name.toLowerCase().includes(searchTerm));
        }

        // Apply sorting
        if (sortState.key) {
            filteredEmployees.sort((a, b) => {
                const valA = a[sortState.key];
                const valB = b[sortState.key];
                let comparison = 0;
                if (typeof valA === 'string') {
                    comparison = valA.localeCompare(valB);
                } else {
                    comparison = valA - valB;
                }
                return sortState.order === 'asc' ? comparison : -comparison;
            });
        }
        
        clearResults();
        renderTable(filteredEmployees);
    };


    // ----- New Feature Functionalities -----

    // Function to handle adding a new employee
    const handleAddEmployee = (event) => {
        event.preventDefault(); // Prevent form from reloading the page
        
        const name = document.getElementById('nameInput').value.trim();
        const age = parseInt(document.getElementById('ageInput').value, 10);
        const department = document.getElementById('departmentInput').value;
        const role = document.getElementById('roleInput').value.trim();
        const salary = parseInt(document.getElementById('salaryInput').value, 10);

        if (name && !isNaN(age) && department && role && !isNaN(salary)) {
            const newId = employees.length > 0 ? Math.max(...employees.map(e => e.id)) + 1 : 1;
            const newEmployee = { id: newId, name, age, department, role, salary };
            
            employees.push(newEmployee);
            addEmployeeForm.reset(); // Clear form fields
            updateDisplay(); // Re-render the table with the new employee
        } else {
            alert('Please fill out all fields correctly.');
        }
    };

    // Function to handle deleting an employee
    const handleDeleteEmployee = (event) => {
        if (event.target.classList.contains('delete-btn')) {
            const employeeId = parseInt(event.target.getAttribute('data-id'), 10);
            if (confirm('Are you sure you want to delete this employee?')) {
                employees = employees.filter(emp => emp.id !== employeeId);
                updateDisplay();
            }
        }
    };
    
    // Function to handle sorting
    const handleSort = (event) => {
        const key = event.target.getAttribute('data-sort');
        if (!key) return;

        if (sortState.key === key) {
            sortState.order = sortState.order === 'asc' ? 'desc' : 'asc';
        } else {
            sortState.key = key;
            sortState.order = 'asc';
        }
        updateDisplay();
    };

    // Function to export currently displayed data to CSV
    const exportToCsv = () => {
        const headers = ['ID', 'Name', 'Age', 'Department', 'Role', 'Salary'];
        const rows = displayedEmployees.map(emp => 
            [emp.id, `"${emp.name}"`, emp.age, emp.department, `"${emp.role}"`, emp.salary].join(',')
        );

        const csvContent = [headers.join(','), ...rows].join('\n');
        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        
        const link = document.createElement('a');
        const url = URL.createObjectURL(blob);
        link.setAttribute('href', url);
        link.setAttribute('download', 'employees.csv');
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    // Function to toggle light/dark theme
    const toggleTheme = () => {
        document.body.classList.toggle('dark-mode');
        // Save user preference to localStorage
        if (document.body.classList.contains('dark-mode')) {
            localStorage.setItem('theme', 'dark');
        } else {
            localStorage.setItem('theme', 'light');
        }
    };
    
    // Function to apply saved theme on load
    const applySavedTheme = () => {
        const savedTheme = localStorage.getItem('theme');
        if (savedTheme === 'dark') {
            document.body.classList.add('dark-mode');
        }
    };

    // ----- Original Functionalities (Adapted/Unchanged) -----

    const convertNamesToUppercase = () => {
        clearResults();
        const updatedEmployees = displayedEmployees.map(emp => ({ ...emp, name: emp.name.toUpperCase() }));
        renderTable(updatedEmployees); // Renders temporary view, doesn't alter source
    };

    const calculateAverageSalary = () => {
        clearResults();
        // This calculation is always based on the full, original employee list
        if (employees.length === 0) {
            avgSalaryResult.textContent = 'No employees to calculate salary.';
            return;
        }
        const totalSalary = employees.reduce((acc, emp) => acc + emp.salary, 0);
        const averageSalary = totalSalary / employees.length;
        avgSalaryResult.textContent = `Average Salary (All Employees): $${averageSalary.toFixed(2).toLocaleString()}`;
    };
    
    const clearResults = () => {
        avgSalaryResult.textContent = '';
        searchedEmployeeResult.innerHTML = '';
    };


    // ----- Bind Event Listeners -----

    // Filters and Display
    departmentFilter.addEventListener('change', updateDisplay);
    searchInput.addEventListener('input', updateDisplay);
    document.querySelector('thead').addEventListener('click', handleSort);

    // Action Buttons
    toUpperCaseBtn.addEventListener('click', convertNamesToUppercase);
    avgSalaryBtn.addEventListener('click', calculateAverageSalary);
    exportCsvBtn.addEventListener('click', exportToCsv);

    // New Features
    addEmployeeForm.addEventListener('submit', handleAddEmployee);
    employeeTableBody.addEventListener('click', handleDeleteEmployee); // Event delegation for delete
    themeToggleBtn.addEventListener('click', toggleTheme);

    // ----- Initial Setup on Page Load -----
    applySavedTheme(); // Check for and apply saved theme first
    updateDisplay(); // Initial table render
});
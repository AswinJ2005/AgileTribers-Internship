// src/App.jsx

import React, { useState, useContext, useMemo } from 'react';
import { ExpenseProvider, ExpenseContext } from './context/ExpenseContext';
import { Container, Grid, Typography, Paper, Box } from '@mui/material';

// --- THIS IS THE MOST IMPORTANT SECTION TO CHECK ---
import ExpenseForm from './components/ExpenseForm'; // <-- NO CURLY BRACES HERE
import ExpenseChart from './components/ExpenseChart';
import ExpenseList from './components/ExpenseList';
import FilterControls from './components/FilterControls';
import BudgetProgressBar from './components/BudgetProgressBar';
import MonthlyBarChart from './components/MonthlyBarChart';
import Notification from './components/Notification';
// --------------------------------------------------

// ... (the rest of the App.jsx code is the same as the previous response)
// A component to calculate and display the total of *filtered* expenses
const TotalExpenses = ({ expenses }) => {
  const total = expenses.reduce((acc, expense) => acc + expense.amount, 0);
  const formattedTotal = new Intl.NumberFormat('en-IN', {
    style: 'currency', currency: 'INR',
  }).format(total);

  return (
    <Paper elevation={3} sx={{ p: 2, mb: 2, textAlign: 'center' }}>
      <Typography variant="body1" color="text.secondary">Total of Displayed Expenses</Typography>
      <Typography variant="h4" component="h2">
        {formattedTotal}
      </Typography>
    </Paper>
  );
};


function App() {
  const { expenses } = useContext(ExpenseContext);

  const [filters, setFilters] = useState({
    searchTerm: '',
    category: 'All',
    sortBy: 'date_desc',
  });

  const filteredAndSortedExpenses = useMemo(() => {
    let result = expenses.filter(e => 
        e.description.toLowerCase().includes(filters.searchTerm.toLowerCase()) &&
        (filters.category === 'All' || e.category === filters.category)
    );

    switch (filters.sortBy) {
      case 'date_asc': result.sort((a, b) => new Date(a.date) - new Date(b.date)); break;
      case 'amount_desc': result.sort((a, b) => b.amount - a.amount); break;
      case 'amount_asc': result.sort((a, b) => a.amount - b.amount); break;
      default: result.sort((a, b) => new Date(b.date) - new Date(a.date)); break;
    }
    return result;
  }, [expenses, filters]);

  return (
      <Container maxWidth="xl" sx={{ mt: 4, mb: 4 }}>
        <Typography variant="h3" gutterBottom component="h1" align="center">
          Advanced Expense Tracker
        </Typography>

        <BudgetProgressBar />
        <FilterControls filters={filters} setFilters={setFilters} />
        
        <Grid container spacing={3} sx={{ mt: 1 }}>
          <Grid item xs={12} md={4}>
             <ExpenseForm />
          </Grid>
          <Grid item xs={12} md={8}>
            <TotalExpenses expenses={filteredAndSortedExpenses} />
            <Grid container spacing={3}>
              <Grid item xs={12} lg={5}>
                <ExpenseChart expenses={filteredAndSortedExpenses} />
              </Grid>
              <Grid item xs={12} lg={7}>
                <MonthlyBarChart expenses={filteredAndSortedExpenses} />
              </Grid>
            </Grid>
          </Grid>
          <Grid item xs={12}>
            <ExpenseList expenses={filteredAndSortedExpenses} />
          </Grid>
        </Grid>
        <Notification />
      </Container>
  );
}

function AppWrapper() {
  return (
    <ExpenseProvider>
      <App />
    </ExpenseProvider>
  );
}

export default AppWrapper;
// src/index.js (Corrected)

import React from 'react';
import ReactDOM from 'react-dom/client';
import AppWrapper from './App'; // Make sure this points to your App file

const root = ReactDOM.createRoot(document.getElementById('root'));

root.render(
  <React.StrictMode>
    <AppWrapper />
  </React.StrictMode>
);
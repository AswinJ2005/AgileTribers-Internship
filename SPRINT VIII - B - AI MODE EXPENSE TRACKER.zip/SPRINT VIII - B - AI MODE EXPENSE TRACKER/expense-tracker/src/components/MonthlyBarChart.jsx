import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Card, CardContent, CardHeader, Typography, Box } from '@mui/material';
import { format, parseISO } from 'date-fns';

const MonthlyBarChart = ({ expenses }) => {
  const monthlyTotals = expenses.reduce((acc, expense) => {
    const month = format(parseISO(expense.date), 'yyyy-MM');
    acc[month] = (acc[month] || 0) + expense.amount;
    return acc;
  }, {});

  const chartData = Object.keys(monthlyTotals).map(month => ({
    name: format(parseISO(`${month}-01`), 'MMM yyyy'),
    total: monthlyTotals[month],
  })).sort((a,b) => new Date(a.name) - new Date(b.name));

  const formatCurrency = (value) => new Intl.NumberFormat('en-IN', {
    notation: 'compact', compactDisplay: 'short'
  }).format(value);

  return (
    <Card elevation={3} sx={{ height: '100%' }}>
      <CardHeader title="Monthly Spending" subheader="Based on filtered results" />
      <CardContent>
        {chartData.length > 0 ? (
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={chartData} margin={{ top: 5, right: 20, left: 20, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis tickFormatter={formatCurrency} />
              <Tooltip
                formatter={(value) => new Intl.NumberFormat('en-IN', {
                  style: 'currency', currency: 'INR'
                }).format(value)}
              />
              <Legend />
              <Bar dataKey="total" fill="#8884d8" name="Total Spending" />
            </BarChart>
          </ResponsiveContainer>
        ) : (
          <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: 250 }}>
            <Typography>No data to display for these filters.</Typography>
          </Box>
        )}
      </CardContent>
    </Card>
  );
};

export default MonthlyBarChart;
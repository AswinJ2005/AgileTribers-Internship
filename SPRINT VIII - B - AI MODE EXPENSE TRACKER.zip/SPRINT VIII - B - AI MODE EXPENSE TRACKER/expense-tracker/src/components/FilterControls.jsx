import React from 'react';
import { TextField, Select, MenuItem, FormControl, InputLabel, Grid, Paper } from '@mui/material';

const CATEGORIES = ['Food', 'Transport', 'Shopping', 'Entertainment', 'Other'];

const FilterControls = ({ filters, setFilters }) => {
  const handleFilterChange = (e) => {
    const { name, value } = e.target;
    setFilters(prev => ({ ...prev, [name]: value }));
  };

  return (
    <Paper elevation={3} sx={{ p: 2, mb: 3 }}>
      <Grid container spacing={2} alignItems="center">
        <Grid item xs={12} md={5}>
          <TextField
            fullWidth
            label="Search by Description"
            name="searchTerm"
            value={filters.searchTerm}
            onChange={handleFilterChange}
            variant="outlined"
            size="small"
          />
        </Grid>
        <Grid item xs={6} md={3.5}>
          <FormControl fullWidth size="small">
            <InputLabel>Category</InputLabel>
            <Select
              name="category"
              value={filters.category}
              label="Category"
              onChange={handleFilterChange}
            >
              <MenuItem value="All">All Categories</MenuItem>
              {CATEGORIES.map(cat => <MenuItem key={cat} value={cat}>{cat}</MenuItem>)}
            </Select>
          </FormControl>
        </Grid>
        <Grid item xs={6} md={3.5}>
          <FormControl fullWidth size="small">
            <InputLabel>Sort By</InputLabel>
            <Select
              name="sortBy"
              value={filters.sortBy}
              label="Sort By"
              onChange={handleFilterChange}
            >
              <MenuItem value="date_desc">Date (Newest First)</MenuItem>
              <MenuItem value="date_asc">Date (Oldest First)</MenuItem>
              <MenuItem value="amount_desc">Amount (High to Low)</MenuItem>
              <MenuItem value="amount_asc">Amount (Low to High)</MenuItem>
            </Select>
          </FormControl>
        </Grid>
      </Grid>
    </Paper>
  );
};

export default FilterControls;
import React, { useContext } from 'react';
import { Snackbar, Alert } from '@mui/material';
import { ExpenseContext } from '../context/ExpenseContext';

const Notification = () => {
  const { notification, dispatch } = useContext(ExpenseContext);

  const handleClose = (event, reason) => {
    if (reason === 'clickaway') {
      return;
    }
    dispatch({ type: 'CLOSE_NOTIFICATION' });
  };

  return (
    <Snackbar
      open={notification.open}
      autoHideDuration={4000}
      onClose={handleClose}
      anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
    >
      <Alert onClose={handleClose} severity={notification.severity} sx={{ width: '100%' }} variant="filled">
        {notification.message}
      </Alert>
    </Snackbar>
  );
};

export default Notification;
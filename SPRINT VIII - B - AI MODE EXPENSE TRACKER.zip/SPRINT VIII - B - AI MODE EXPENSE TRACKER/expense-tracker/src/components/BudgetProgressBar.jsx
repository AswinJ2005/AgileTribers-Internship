import React, { useContext } from 'react';
import { ExpenseContext } from '../context/ExpenseContext';
import { Box, Typography, LinearProgress, Paper } from '@mui/material';

const BudgetProgressBar = () => {
  const { expenses, budget } = useContext(ExpenseContext);
  const totalExpenses = expenses.reduce((acc, expense) => acc + expense.amount, 0);
  const percentage = Math.min((totalExpenses / budget) * 100, 100);
  const remaining = budget - totalExpenses;

  const formatCurrency = (value) => new Intl.NumberFormat('en-IN', {
    style: 'currency', currency: 'INR', maximumFractionDigits: 0
  }).format(value);

  return (
    <Paper elevation={3} sx={{ p: 3, mb: 3 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 1 }}>
        <Typography variant="h5" component="h3">Monthly Budget</Typography>
        <Typography variant="h6">{`${formatCurrency(totalExpenses)} / ${formatCurrency(budget)}`}</Typography>
      </Box>
      <LinearProgress
        variant="determinate"
        value={percentage}
        color={percentage > 85 ? "error" : "primary"}
        sx={{ height: 12, borderRadius: 5, mb: 1 }}
      />
      <Typography variant="body2" color="text.secondary" align="right">
        {remaining >= 0 ? `${formatCurrency(remaining)} Remaining` : `${formatCurrency(Math.abs(remaining))} Over Budget`}
      </Typography>
    </Paper>
  );
};

export default BudgetProgressBar;
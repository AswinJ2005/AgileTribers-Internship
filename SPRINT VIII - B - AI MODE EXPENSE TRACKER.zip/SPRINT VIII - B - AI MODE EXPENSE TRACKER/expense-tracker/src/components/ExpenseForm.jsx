// src/components/ExpenseForm.jsx

import React, { useState, useContext } from 'react';
import { ExpenseContext } from '../context/ExpenseContext';
import { TextField, Button, Select, MenuItem, FormControl, InputLabel, Card, CardContent, CardHeader, Box } from '@mui/material';
import { LocalizationProvider, DatePicker } from '@mui/x-date-pickers';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import { format } from 'date-fns';

const ExpenseForm = () => {
  const { dispatch, budget, expenses } = useContext(ExpenseContext);
  const [description, setDescription] = useState('');
  const [amount, setAmount] = useState('');
  const [category, setCategory] = useState('');
  const [date, setDate] = useState(new Date());

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!description || !amount || !category) return;

    const newExpense = {
      id: Date.now(),
      description,
      amount: parseFloat(amount),
      category,
      date: format(date, 'yyyy-MM-dd'),
    };

    dispatch({ type: 'ADD_EXPENSE', payload: newExpense });
    
    const totalExpenses = expenses.reduce((sum, exp) => sum + exp.amount, 0) + newExpense.amount;
    if (totalExpenses > budget) {
      dispatch({ type: 'SET_NOTIFICATION', payload: { message: 'Warning: You have exceeded your budget!', severity: 'warning' }});
    } else {
      dispatch({ type: 'SET_NOTIFICATION', payload: { message: 'Expense Added Successfully!', severity: 'success' }});
    }

    setDescription(''); setAmount(''); setCategory(''); setDate(new Date());
  };

  return (
    <LocalizationProvider dateAdapter={AdapterDateFns}>
      <Card elevation={3} sx={{ height: '100%' }}>
        <CardHeader title="Add New Expense" />
        <CardContent>
          <Box component="form" onSubmit={handleSubmit} noValidate sx={{ mt: 1 }}>
            <TextField margin="normal" required fullWidth label="Description" value={description} onChange={(e) => setDescription(e.target.value)} />
            <TextField margin="normal" required fullWidth label="Amount (₹)" type="number" value={amount} onChange={(e) => setAmount(e.target.value)} />
            <FormControl fullWidth margin="normal">
              <InputLabel>Category</InputLabel>
              <Select value={category} label="Category" onChange={(e) => setCategory(e.target.value)}>
                <MenuItem value={'Food'}>Food</MenuItem>
                <MenuItem value={'Transport'}>Transport</MenuItem>
                <MenuItem value={'Shopping'}>Shopping</MenuItem>
                <MenuItem value={'Entertainment'}>Entertainment</MenuItem>
                <MenuItem value={'Other'}>Other</MenuItem>
              </Select>
            </FormControl>
            <DatePicker
              label="Expense Date"
              value={date}
              onChange={(newDate) => setDate(newDate)}
              renderInput={(params) => <TextField {...params} fullWidth margin="normal" />}
            />
            <Button type="submit" fullWidth variant="contained" sx={{ mt: 3, mb: 2 }}>
              Add Expense
            </Button>
          </Box>
        </CardContent>
      </Card>
    </LocalizationProvider>
  );
};

export default ExpenseForm; 
import React, { useContext } from 'react';
import { ExpenseContext } from '../context/ExpenseContext';
import { List, ListItem, ListItemText, IconButton, Card, CardHeader, CardContent, Typography, Box } from '@mui/material';
import DeleteIcon from '@mui/icons-material/Delete';
import { format, parseISO } from 'date-fns';

const ExpenseList = ({ expenses }) => {
  const { dispatch } = useContext(ExpenseContext);

  const handleDelete = (id) => {
    dispatch({ type: 'DELETE_EXPENSE', payload: id });
    dispatch({ type: 'SET_NOTIFICATION', payload: { message: 'Expense Deleted', severity: 'info' }});
  };

  const formatCurrency = (value) => new Intl.NumberFormat('en-IN', {
    style: 'currency', currency: 'INR'
  }).format(value);

  return (
    <Card elevation={3}>
      <CardHeader title="Transaction History" />
      <CardContent>
        {expenses.length > 0 ? (
          <List sx={{ maxHeight: 400, overflow: 'auto' }}>
            {expenses.map((expense) => (
              <ListItem
                key={expense.id}
                secondaryAction={
                  <IconButton edge="end" aria-label={`delete ${expense.description}`} onClick={() => handleDelete(expense.id)}>
                    <DeleteIcon />
                  </IconButton>
                }
                divider
              >
                <ListItemText
                  primary={expense.description}
                  secondary={`${expense.category} on ${format(parseISO(expense.date), 'do MMM, yyyy')}`}
                />
                <Typography variant="body1">
                  {formatCurrency(expense.amount)}
                </Typography>
              </ListItem>
            ))}
          </List>
        ) : (
          <Box sx={{ textAlign: 'center', p: 3 }}>
             <Typography variant="body1" color="text.secondary">
                No transactions match your current filters.
             </Typography>
          </Box>
        )}
      </CardContent>
    </Card>
  );
};

export default ExpenseList;
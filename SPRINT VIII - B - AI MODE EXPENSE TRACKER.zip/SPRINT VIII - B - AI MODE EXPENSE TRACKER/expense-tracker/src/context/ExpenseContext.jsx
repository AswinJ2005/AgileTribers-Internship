// src/context/ExpenseContext.jsx (Corrected)

import React, { createContext, useReducer } from 'react'; // FIXED: Correct import statement

// The reducer function handles state changes
const AppReducer = (state, action) => {
  switch (action.type) {
    case 'ADD_EXPENSE':
      return {
        ...state,
        expenses: [action.payload, ...state.expenses],
      };
    case 'DELETE_EXPENSE':
      return {
        ...state,
        expenses: state.expenses.filter(
          (expense) => expense.id !== action.payload
        ),
      };
    case 'SET_NOTIFICATION':
      return {
        ...state,
        notification: {
          open: true,
          message: action.payload.message,
          severity: action.payload.severity,
        },
      };
    case 'CLOSE_NOTIFICATION':
      return {
        ...state,
        notification: { ...state.notification, open: false },
      };
    default:
      return state;
  }
};

// Initial state now includes dates, a budget, and notification state
const initialState = {
  budget: 50000, // Example budget in INR
  expenses: [
    { id: 1, description: 'Groceries', amount: 3000, category: 'Food', date: '2023-10-25' },
    { id: 2, description: 'Metro Card', amount: 500, category: 'Transport', date: '2023-10-20' },
    { id: 3, description: 'Movie Tickets', amount: 800, category: 'Entertainment', date: '2023-10-15' },
    { id: 4, description: 'Diwali Shopping', amount: 7500, category: 'Shopping', date: '2023-11-05' },
    { id: 5, description: 'Lunch', amount: 250, category: 'Food', date: '2023-11-01' },
  ],
  notification: {
    open: false,
    message: '',
    severity: 'info', // can be 'success', 'error', 'warning', 'info'
  },
};

// Create context
export const ExpenseContext = createContext();

// Provider component
export const ExpenseProvider = (props) => {
  const [state, dispatch] = useReducer(AppReducer, initialState);

  return (
    <ExpenseContext.Provider
      value={{
        expenses: state.expenses,
        budget: state.budget,
        notification: state.notification,
        dispatch,
      }}
    >
      {props.children}
    </ExpenseContext.Provider>
  );
};
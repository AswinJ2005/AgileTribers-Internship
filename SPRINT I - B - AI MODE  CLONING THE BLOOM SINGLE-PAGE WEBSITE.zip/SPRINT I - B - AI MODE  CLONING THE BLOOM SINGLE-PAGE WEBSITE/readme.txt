Website Clone: Bloom (Single-Page Version) using AI Mode

AI used: Gemini 2.5 Pro Preview by Google AI Studio

This project is a static HTML and CSS clone of the "Bloom" website layout. The goal was to accurately replicate the design of a provided screenshot using only fundamental web technologies.

Project Overview

The website is built as a single, self-contained index.html file. All the necessary CSS styles and image data have been embedded directly into the HTML file, so no external files or folders are required to run it.

Sections Recreated

Header: Includes the site logo and the main navigation bar.

Hero Section: An introductory area featuring text, a "Learn More" button, and a feature image.

Services Section: A three-card layout for showcasing services or portfolio items.

Footer: A multi-column footer with sections for "Latest Posts", "About", and "Stay Connected".

Technology Stack

HTML: For the structure and content of the page.

CSS: For all styling, layout, colors, fonts, and responsiveness.

No JavaScript, frameworks, or external libraries were used.

How to Run

Copy all the code from the index.html file.

Paste it into a new file and save it as index.html.

Open the index.html file in any web browser (like Chrome, Firefox, or Edge).

That's it! The entire webpage will be displayed correctly.
import React, { useState, useContext } from 'react';
import { ExpenseContext } from '../context/ExpenseContext';
import {
  TextField,
  Button,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Card,
  CardContent,
  CardHeader,
  Box,
} from '@mui/material';

const ExpenseForm = () => {
  const { dispatch } = useContext(ExpenseContext);
  const [description, setDescription] = useState('');
  const [amount, setAmount] = useState('');
  const [category, setCategory] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!description || !amount || !category) return;

    const newExpense = {
      id: Date.now(), // simple unique id
      description,
      amount: parseFloat(amount),
      category,
    };

    // Dispatching the 'ADD_EXPENSE' action.
    // This updates the global state in ExpenseContext.
    // Any component subscribed to this context will re-render with the new state.
    dispatch({
      type: 'ADD_EXPENSE',
      payload: newExpense,
    });

    // Reset form fields
    setDescription('');
    setAmount('');
    setCategory('');
  };

  return (
    <Card elevation={3}>
      <CardHeader title="Add New Expense" />
      <CardContent>
        <Box component="form" onSubmit={handleSubmit} noValidate sx={{ mt: 1 }}>
          <TextField
            margin="normal"
            required
            fullWidth
            id="description"
            label="Description"
            name="description"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
          />
          <TextField
            margin="normal"
            required
            fullWidth
            name="amount"
            label="Amount"
            type="number"
            id="amount"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
          />
          <FormControl fullWidth margin="normal">
            <InputLabel id="category-label">Category</InputLabel>
            <Select
              labelId="category-label"
              id="category"
              value={category}
              label="Category"
              onChange={(e) => setCategory(e.target.value)}
            >
              <MenuItem value={'Food'}>Food</MenuItem>
              <MenuItem value={'Transport'}>Transport</MenuItem>
              <MenuItem value={'Shopping'}>Shopping</MenuItem>
              <MenuItem value={'Entertainment'}>Entertainment</MenuItem>
              <MenuItem value={'Other'}>Other</MenuItem>
            </Select>
          </FormControl>
          <Button
            type="submit"
            fullWidth
            variant="contained"
            sx={{ mt: 3, mb: 2 }}
          >
            Add Expense
          </Button>
        </Box>
      </CardContent>
    </Card>
  );
};

export default ExpenseForm;
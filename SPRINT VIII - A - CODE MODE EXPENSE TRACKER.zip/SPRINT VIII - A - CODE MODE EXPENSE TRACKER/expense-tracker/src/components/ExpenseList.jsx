// src/components/ExpenseList.jsx

import React, { useContext } from 'react';
import { ExpenseContext } from '../context/ExpenseContext';
import {
  List,
  ListItem,
  ListItemText,
  IconButton,
  Card,
  CardHeader,
  CardContent,
  Typography,
} from '@mui/material';
import DeleteIcon from '@mui/icons-material/Delete';

const ExpenseList = () => {
  const { expenses, dispatch } = useContext(ExpenseContext);

  const handleDelete = (id) => {
    dispatch({
      type: 'DELETE_EXPENSE',
      payload: id,
    });
  };

  return (
    <Card elevation={3}>
      <CardHeader title="Transaction History" />
      <CardContent>
        {expenses.length > 0 ? (
          <List>
            {expenses.map((expense) => (
              <ListItem
                key={expense.id}
                secondaryAction={
                  <IconButton
                    edge="end"
                    aria-label="delete"
                    onClick={() => handleDelete(expense.id)}
                  >
                    <DeleteIcon />
                  </IconButton>
                }
                divider
              >
                <ListItemText
                  primary={expense.description}
                  secondary={expense.category}
                />
                <Typography variant="body1" color={expense.amount > 0 ? 'textPrimary' : 'error'}>
                  {/* ** CHANGE: Format the individual expense amount as INR ** */}
                  {new Intl.NumberFormat('en-IN', {
                    style: 'currency',
                    currency: 'INR',
                  }).format(expense.amount)}
                </Typography>
              </ListItem>
            ))}
          </List>
        ) : (
          <Typography variant="body1" color="text.secondary" align="center">
            No transactions yet.
          </Typography>
        )}
      </CardContent>
    </Card>
  );
};

export default ExpenseList;
// src/App.jsx

import React, { useContext } from 'react';
import { ExpenseProvider, ExpenseContext } from './context/ExpenseContext';
import ExpenseForm from './components/ExpenseForm';
import ExpenseChart from './components/ExpenseChart';
import ExpenseList from './components/ExpenseList';

import { Container, Grid, Typography, Paper, Box } from '@mui/material';

// A component to calculate and display the total expenses
const TotalExpenses = () => {
  const { expenses } = useContext(ExpenseContext);
  const total = expenses.reduce((acc, expense) => acc + expense.amount, 0);

  // ** CHANGE: Format the total as Indian Rupees (INR) **
  const formattedTotal = new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
  }).format(total);

  return (
    <Paper elevation={3} sx={{ p: 2, mb: 3, textAlign: 'center' }}>
      <Typography variant="h4" component="h2">
        Total Expenses: {formattedTotal}
      </Typography>
    </Paper>
  );
};

function App() {
  return (
    // The ExpenseProvider wraps the application, making the state available to all components
    <ExpenseProvider>
      <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
        <Typography variant="h3" gutterBottom component="h1" align="center">
          Expense Tracker
        </Typography>

        <TotalExpenses />

        <Grid container spacing={3}>
          {/* Form and Chart side-by-side */}
          <Grid item xs={12} md={6}>
            <ExpenseForm />
          </Grid>
          <Grid item xs={12} md={6}>
            <ExpenseChart />
          </Grid>

          {/* Expense list below */}
          <Grid item xs={12}>
            <Box mt={3}>
              <ExpenseList />
            </Box>
          </Grid>
        </Grid>
      </Container>
    </ExpenseProvider>
  );
}

export default App;
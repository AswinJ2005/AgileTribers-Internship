import React, { createContext, useReducer } from 'react';

// The reducer function handles state changes
const AppReducer = (state, action) => {
  switch (action.type) {
    case 'ADD_EXPENSE':
      return {
        ...state,
        expenses: [...state.expenses, action.payload],
      };
    case 'DELETE_EXPENSE':
      return {
        ...state,
        expenses: state.expenses.filter(
          (expense) => expense.id !== action.payload
        ),
      };
    default:
      return state;
  }
};

// Initial state with some dummy data for better visualization on load
const initialState = {
  expenses: [
    { id: 1, description: 'Coffee', amount: 3, category: 'Food' },
    { id: 2, description: 'Train Ticket', amount: 25, category: 'Transport' },
    { id: 3, description: 'Movie', amount: 15, category: 'Entertainment' },
    { id: 4, description: 'Lunch', amount: 12, category: 'Food' },
  ],
};

// Create context
export const ExpenseContext = createContext();

// Provider component
export const ExpenseProvider = (props) => {
  const [state, dispatch] = useReducer(AppReducer, initialState);

  return (
    <ExpenseContext.Provider
      value={{
        expenses: state.expenses,
        dispatch,
      }}
    >
      {props.children}
    </ExpenseContext.Provider>
  );
};
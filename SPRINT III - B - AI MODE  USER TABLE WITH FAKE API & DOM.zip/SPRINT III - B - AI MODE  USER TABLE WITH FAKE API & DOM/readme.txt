User Management Dashboard

✨ Features

✅ Add, Edit, and Delete users.

✅ Live Search & Filter the entire table.

✅ Sort data by any column (Name, Email, etc.).

✅ Pagination to navigate through user pages.

✅ Undo a Delete action within 5 seconds.

✅ Export the current view to a CSV file.

✅ Select and delete multiple users at once.

✅ Toggle between Dark and Light themes.

✅ Fully Responsive for both mobile and desktop screens.

🚀 How to Run

No complicated setup is needed.

Download the files (index.html, style.css, script.js).

Open index.html in your web browser.

That's it! The application will run locally.

🛠️ Built With

HTML5

CSS3 

JavaScript
document.addEventListener('DOMContentLoaded', () => {
    // --- STATE MANAGEMENT ---
    let allUsers = [];
    let displayedUsers = [];
    let currentPage = 1;
    const rowsPerPage = 10;
    let sortState = { key: 'name', order: 'asc' };
    let undoTimeout = null;
    let deletedUserCache = null;

    // --- DOM ELEMENT REFERENCES ---
    const tableBody = document.getElementById('table-body');
    const searchBox = document.getElementById('search-box');
    const prevPageBtn = document.getElementById('prev-page');
    const nextPageBtn = document.getElementById('next-page');
    const pageInfo = document.getElementById('page-info');
    const toastContainer = document.getElementById('toast-container');
    const selectAllCheckbox = document.getElementById('select-all-checkbox');
    const bulkDeleteBtn = document.getElementById('bulk-delete-btn');
    const exportCsvBtn = document.getElementById('export-csv-btn');
    const addUserModal = document.getElementById('add-user-modal');
    const addUserForm = document.getElementById('add-user-form');
    const themeToggle = document.getElementById('theme-toggle');

    // --- MAIN RENDER PIPELINE ---
    function render() {
        const searchTerm = searchBox.value.toLowerCase();
        const filteredUsers = allUsers.filter(user =>
            Object.values(user).some(val =>
                String(val).toLowerCase().includes(searchTerm)
            )
        );
        displayedUsers = filteredUsers.sort((a, b) => {
            const valA = String(a[sortState.key] || '').toLowerCase();
            const valB = String(b[sortState.key] || '').toLowerCase();
            if (valA < valB) return sortState.order === 'asc' ? -1 : 1;
            if (valA > valB) return sortState.order === 'asc' ? 1 : -1;
            return 0;
        });
        const totalPages = Math.ceil(displayedUsers.length / rowsPerPage);
        currentPage = Math.max(1, Math.min(currentPage, totalPages || 1));
        const paginatedUsers = displayedUsers.slice((currentPage - 1) * rowsPerPage, currentPage * rowsPerPage);

        updateTable(paginatedUsers);
        updatePagination(totalPages);
        updateBulkDeleteButtonState();
    }

    async function fetchUsers() {
        try {
            const response = await fetch('https://jsonplaceholder.typicode.com/users');
            if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
            allUsers = await response.json();
            render();
        } catch (error) {
            console.error("Could not fetch users:", error);
            tableBody.innerHTML = '<tr><td colspan="6" style="text-align:center; color:red;">Failed to load user data.</td></tr>';
        }
    }

    // --- DOM UPDATERS ---
    function createUserRow(user) {
        const row = document.createElement('tr');
        row.dataset.userId = user.id;

        const initials = user.name.split(' ').map(n => n[0]).join('');
        const avatarUrl = `https://ui-avatars.com/api/?name=${encodeURIComponent(user.name)}&background=random&color=fff`;

        row.innerHTML = `
            <td data-label="Select"><input type="checkbox" class="row-checkbox"></td>
            <td data-label="Name" class="name-cell">
                <img src="${avatarUrl}" alt="${initials}" class="avatar" title="${user.name}">
                <span data-field="name">${user.name}</span>
            </td>
            <td data-label="Username"><span data-field="username">${user.username}</span></td>
            <td data-label="Email"><span data-field="email">${user.email}</span></td>
            <td data-label="Phone"><span data-field="phone">${user.phone}</span></td>
            <td data-label="Actions" class="action-cell">
                <button class="btn btn-edit" title="Edit User">Edit</button>
                <button class="btn btn-delete" title="Delete User">Delete</button>
            </td>
        `;
        return row;
    }

    function updateTable(users) {
        tableBody.innerHTML = '';
        if (users.length === 0) {
            tableBody.innerHTML = '<tr><td colspan="6" style="text-align:center;">No users found.</td></tr>';
            return;
        }
        users.forEach(user => tableBody.appendChild(createUserRow(user)));
        selectAllCheckbox.checked = false;
    }

    function updatePagination(totalPages) {
        pageInfo.textContent = `Page ${currentPage} of ${totalPages || 1}`;
        prevPageBtn.disabled = currentPage <= 1;
        nextPageBtn.disabled = currentPage >= totalPages;
    }

    function updateBulkDeleteButtonState() {
        const selectedCount = tableBody.querySelectorAll('.row-checkbox:checked').length;
        bulkDeleteBtn.disabled = selectedCount === 0;
        bulkDeleteBtn.textContent = `Delete Selected (${selectedCount})`;
    }
    
    function showToast(message, type = 'info', options = { duration: 5000 }) {
        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        
        let content = `<span>${message}</span>`;
        if (options.undoCallback) content += `<button class="toast-undo">Undo</button>`;
        toast.innerHTML = content;
        
        toastContainer.appendChild(toast);
        
        if (options.undoCallback) {
            toast.querySelector('.toast-undo').onclick = () => {
                options.undoCallback(); toast.remove(); clearTimeout(undoTimeout);
            };
        }
        setTimeout(() => toast.remove(), options.duration);
    }
    
    // --- EVENT HANDLERS ---
    
    // *** CRITICAL FIX: REWRITTEN handleEditSave FUNCTION ***
    function handleEditSave(button) {
        const row = button.closest('tr');
        const isEditing = button.classList.contains('btn-save');

        if (isEditing) {
            // --- SAVE LOGIC ---
            const inputs = row.querySelectorAll('input[data-field]');
            let isValid = true;
            let updatedData = {};

            inputs.forEach(input => {
                input.style.borderColor = ''; // Reset border
                if (!validateInput(input.dataset.field, input.value)) {
                    isValid = false;
                    input.style.borderColor = 'red';
                }
                updatedData[input.dataset.field] = input.value;
            });

            if (!isValid) {
                showToast("Invalid input. Please check the highlighted fields.", "error");
                return;
            }

            // Update the data model first
            const userId = parseInt(row.dataset.userId);
            const userIndex = allUsers.findIndex(u => u.id === userId);
            if(userIndex > -1) allUsers[userIndex] = { ...allUsers[userIndex], ...updatedData };
            
            // Then update the DOM
            inputs.forEach(input => {
                const field = input.dataset.field;
                const span = row.querySelector(`span[data-field="${field}"]`);
                span.textContent = input.value;
                span.style.display = ''; // Make span visible again
                input.remove(); // Remove the input field
            });

            button.textContent = 'Edit';
            button.classList.replace('btn-save', 'btn-edit');
            row.classList.remove('row-editing');
            showToast("User updated successfully!", "success");

        } else {
            // --- EDIT LOGIC ---
            const spans = row.querySelectorAll('span[data-field]');
            spans.forEach(span => {
                const currentValue = span.textContent;
                const field = span.dataset.field;
                // Create a robust input element
                const input = document.createElement('input');
                input.type = 'text';
                input.value = currentValue;
                input.dataset.field = field; // Carry the field key
                
                span.style.display = 'none'; // Hide the span
                span.parentNode.insertBefore(input, span.nextSibling); // Insert input after span
            });

            button.textContent = 'Save';
            button.classList.replace('btn-edit', 'btn-save');
            row.classList.add('row-editing');
        }
    }
    
    function handleDelete(button) {
        if (!confirm('Are you sure you want to delete this user?')) return;
        
        const row = button.closest('tr');
        const userId = parseInt(row.dataset.userId);
        const userIndex = allUsers.findIndex(u => u.id === userId);
        if (userIndex === -1) return;

        deletedUserCache = { user: { ...allUsers[userIndex] }, index: userIndex };
        allUsers.splice(userIndex, 1);
        render();

        clearTimeout(undoTimeout);
        showToast("User deleted.", "info", {
            duration: 5000,
            undoCallback: () => {
                allUsers.splice(deletedUserCache.index, 0, deletedUserCache.user);
                deletedUserCache = null; render();
                showToast("Deletion undone.", "success");
            }
        });
        undoTimeout = setTimeout(() => { deletedUserCache = null; }, 5000);
    }
    
    // --- UTILITY FUNCTIONS & EVENT BINDING ---
    function validateInput(field, value) {
        const trimmedValue = value.trim();
        if (trimmedValue === '') return false;
        if (field === 'email') return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(trimmedValue);
        return true;
    }

    function exportToCSV() {
        if (displayedUsers.length === 0) {
            showToast("No data to export.", "error"); return;
        }
        const headers = Object.keys(displayedUsers[0]);
        const rows = displayedUsers.map(user => 
            headers.map(header => `"${String(user[header]).replace(/"/g, '""')}"`).join(',')
        );
        const csvContent = "data:text/csv;charset=utf-8," + headers.join(',') + '\n' + rows.join('\n');
        
        const link = document.createElement("a");
        link.href = encodeURI(csvContent);
        link.download = "users_export.csv";
        link.click();
        showToast("Data exported to CSV!", "info");
    }

    function toggleTheme(isDark) {
        document.documentElement.setAttribute('data-theme', isDark ? 'dark' : 'light');
        localStorage.setItem('theme', isDark ? 'dark' : 'light');
    }

    function init() {
        tableBody.addEventListener('click', (event) => {
            const button = event.target.closest('button');
            if (!button) return;
            if (button.classList.contains('btn-edit') || button.classList.contains('btn-save')) handleEditSave(button);
            if (button.classList.contains('btn-delete')) handleDelete(button);
        });

        tableBody.addEventListener('change', (event) => {
            if (event.target.classList.contains('row-checkbox')) updateBulkDeleteButtonState();
        });

        document.querySelector('#user-table thead').addEventListener('click', (event) => {
            const key = event.target.closest('th')?.querySelector('[data-sort-key]')?.dataset.sortKey;
            if (!key) return;
            sortState.order = (sortState.key === key && sortState.order === 'asc') ? 'desc' : 'asc';
            sortState.key = key;
            document.querySelectorAll('.sort-icon').forEach(i => i.classList.remove('asc', 'desc'));
            event.target.closest('th').querySelector('.sort-icon').classList.add(sortState.order);
            render();
        });

        bulkDeleteBtn.addEventListener('click', () => {
            const checked = tableBody.querySelectorAll('.row-checkbox:checked');
            if (checked.length === 0 || !confirm(`Delete ${checked.length} selected users?`)) return;
            const idsToDelete = Array.from(checked).map(cb => parseInt(cb.closest('tr').dataset.userId));
            allUsers = allUsers.filter(user => !idsToDelete.includes(user.id));
            render();
            showToast(`${checked.length} users deleted.`, "success");
        });

        searchBox.addEventListener('input', render);
        prevPageBtn.addEventListener('click', () => { if(currentPage > 1) { currentPage--; render(); } });
        nextPageBtn.addEventListener('click', () => { currentPage++; render(); });
        selectAllCheckbox.addEventListener('change', () => {
            tableBody.querySelectorAll('.row-checkbox').forEach(cb => cb.checked = selectAllCheckbox.checked);
            updateBulkDeleteButtonState();
        });

        exportCsvBtn.addEventListener('click', exportToCSV);
        document.getElementById('add-user-btn').addEventListener('click', () => addUserModal.style.display = 'block');
        addUserModal.querySelector('.close-button').addEventListener('click', () => addUserModal.style.display = 'none');
        window.addEventListener('click', (event) => { if(event.target === addUserModal) addUserModal.style.display = 'none'; });
        addUserForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const newUser = {
                id: (allUsers.length > 0 ? Math.max(...allUsers.map(u => u.id)) + 1 : 1),
                name: e.target.elements['name-input'].value,
                email: e.target.elements['email-input'].value,
                phone: e.target.elements['phone-input'].value,
                username: e.target.elements['name-input'].value.toLowerCase().replace(/\s/g, ''),
            };
            if(!Object.values(newUser).every(v => validateInput(v.toString(),v.toString()))) {
                 showToast('Please fill all fields with valid data.', 'error');
                 return
            }
            allUsers.unshift(newUser);
            addUserForm.reset(); addUserModal.style.display = 'none'; render();
            showToast('New user added successfully!', 'success');
        });

        const savedTheme = localStorage.getItem('theme') === 'dark';
        themeToggle.checked = savedTheme;
        toggleTheme(savedTheme);
        themeToggle.addEventListener('change', (e) => toggleTheme(e.target.checked));
        
        fetchUsers();
    }
    
    init();
});
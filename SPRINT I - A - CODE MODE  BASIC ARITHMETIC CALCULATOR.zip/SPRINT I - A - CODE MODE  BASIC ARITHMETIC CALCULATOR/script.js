document.addEventListener('DOMContentLoaded', function() {
    const display = document.getElementById('display');
    const buttons = document.querySelector('.buttons');

    buttons.addEventListener('click', function(e) {
        if (e.target.matches('button')) {
            const button = e.target;
            const value = button.dataset.value;

            if (value === 'AC') {
                display.value = '';
            } else if (value === 'DEL') {
                display.value = display.value.slice(0, -1);
            } else if (value === '=') {
                try {
                    let expression = display.value.replace(/x/g, '*').replace(/÷/g, '/');
                    let result = eval(expression);
                    if (result === Infinity || result === -Infinity) {
                        display.value = "Error";
                    } else {
                        display.value = result;
                    }
                } catch (error) {
                    display.value = 'Error';
                }
            } else {
                display.value += value;
            }
        }
    });
});
Basic Arithmetic Calculator

This project is a simple, web-based calculator developed as a front-end exercise. It features a modern, mobile-inspired interface and performs basic arithmetic operations. This project was built to practice interacting with web page elements through JavaScript. 

Features

* Performs basic arithmetic: Addition (+), Subtraction (-), Multiplication (x), and Division (÷). [cite: 4]
* Modern, mobile-calculator-inspired user interface with a dark theme.
* Clickable buttons for a responsive user experience.
* "AC" (All Clear) button to reset the calculator. [cite: 5]
* "DEL" (Delete) button to remove the last entered character.
* Basic error handling for operations like division by zero.

Technologies Used

* HTML: Structures the calculator and its components.
* CSS**: Styles the calculator for a clean, mobile-first presentation.
* JavaScript: Powers the calculator's logic and user interactions.

How to Run

1.  Ensure the following files are in the same project folder:
    * `index.html`
    * `style.css` 
    * `script.js`
2.  Open the `index.html` file in any modern web browser.
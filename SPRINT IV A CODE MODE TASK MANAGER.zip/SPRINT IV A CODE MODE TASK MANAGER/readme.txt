Task Manager with Live Status Dashboard

This project is a simple, browser-based Task Manager designed to simulate asynchronous operations and real-time UI updates. It's built using pure HTML, CSS, and JavaScript as part of a front-end development job simulation.

Users can load a predefined list of tasks, start their progress, stop them, and receive delayed notifications, demonstrating core asynchronous JavaScript concepts.

Features

Asynchronous Task Loading: Loads a list of tasks with a simulated delay using async/await.

Real-Time Progress Updates: Simulates task progress, updating the UI every second using setInterval.

User Controls: Provides buttons to Load Tasks, Start Progress, and Stop Progress (clearInterval).

Delayed Notifications: Demonstrates setTimeout by displaying a message in the notification panel after a 3-second delay.

Visual Feedback: The UI uses color-coded statuses and a dynamic progress bar for clear visual feedback.

Responsive Design: The layout is responsive and adapts to different screen sizes.

How to Use

No installation is required. To run this project:

Clone this repository or download the project folder.

Open the index.html file in your web browser.

Alternatively, you can use a live server extension (like Live Server in VS Code) to serve the folder.

Technology Stack

HTML
CSS
JavaScript
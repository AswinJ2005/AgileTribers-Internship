document.addEventListener('DOMContentLoaded', () => {
    const loadTasksBtn = document.getElementById('loadTasksBtn');
    const startProgressBtn = document.getElementById('startProgressBtn');
    const stopProgressBtn = document.getElementById('stopProgressBtn');
    const delayNotificationBtn = document.getElementById('delayNotificationBtn');
    const taskListDiv = document.getElementById('taskList');
    const notificationsPanel = document.getElementById('notificationsPanel');

    let tasks = [];
    let intervalIds = {};

    const FAKE_TASK_DATA = [
        { id: 1, name: 'Uploading files to server' },
        { id: 2, name: 'Processing video data' },
        { id: 3, name: 'Generating weekly reports' },
        { id: 4, name: 'Backing up database' },
    ];

    const fetchFakeTasks = () => {
        return new Promise((resolve) => {
            setTimeout(() => {
                resolve(FAKE_TASK_DATA);
            }, 1500);
        });
    };

    const loadTasks = async () => {
        taskListDiv.innerHTML = '<p>Loading...</p>';
        try {
            const fetchedTasks = await fetchFakeTasks();
            tasks = fetchedTasks.map(task => ({
                ...task,
                progress: 0,
                status: 'Pending'
            }));
            renderTasks();
        } catch (error) {
            taskListDiv.innerHTML = '<p>Failed to load tasks. Please try again.</p>';
            console.error('Error fetching tasks:', error);
        }
    };

    const renderTasks = () => {
        taskListDiv.innerHTML = '';
        if (tasks.length === 0) {
            taskListDiv.innerHTML = '<p>Click "Load Tasks" to begin.</p>';
            return;
        }

        tasks.forEach(task => {
            const taskCard = document.createElement('div');
            taskCard.className = 'task-card';
            taskCard.id = `task-${task.id}`;
            taskCard.innerHTML = `
                <div class="task-name">${task.name}</div>
                <div class="task-status">${task.status}</div>
                <div class="progress-container">
                    <div class="progress-bar" style="width: ${task.progress}%;">${task.progress}%</div>
                </div>
            `;
            taskListDiv.appendChild(taskCard);
        });
    };

    const updateTaskUI = (taskId) => {
        const task = tasks.find(t => t.id === taskId);
        if (!task) return;

        const taskCard = document.getElementById(`task-${taskId}`);
        const progressBar = taskCard.querySelector('.progress-bar');
        const taskStatus = taskCard.querySelector('.task-status');
        
        progressBar.style.width = `${task.progress}%`;
        progressBar.textContent = `${task.progress}%`;
        
        taskStatus.textContent = task.status;
        
        taskCard.classList.remove('status-in-progress', 'status-completed');
        if (task.status === 'In Progress') {
            taskCard.classList.add('status-in-progress');
        } else if (task.status === 'Completed') {
            taskCard.classList.add('status-completed');
        }
    };

    const startAllProgress = () => {
        tasks.forEach(task => {
            if (task.progress < 100 && !intervalIds[task.id]) {
                task.status = 'In Progress';

                intervalIds[task.id] = setInterval(() => {
                    task.progress += 10;

                    if (task.progress >= 100) {
                        task.progress = 100;
                        task.status = 'Completed';
                        clearInterval(intervalIds[task.id]);
                        delete intervalIds[task.id];
                    }
                    updateTaskUI(task.id);
                }, 1000);
                
                updateTaskUI(task.id);
            }
        });
    };
    
    const stopAllProgress = () => {
        Object.keys(intervalIds).forEach(taskId => {
            clearInterval(intervalIds[taskId]);
            const task = tasks.find(t => t.id == taskId);
            if (task && task.status === 'In Progress') {
                task.status = 'Stopped';
                updateTaskUI(task.id);
            }
            delete intervalIds[taskId];
        });
    };
    
    const showDelayedNotification = () => {
        addNotification("Notification scheduled...");
        setTimeout(() => {
            addNotification("This is your delayed message!");
        }, 3000);
    };

    const addNotification = (message) => {
        const p = document.createElement('p');
        p.textContent = `[${new Date().toLocaleTimeString()}] ${message}`;
        notificationsPanel.prepend(p);
    };

    loadTasksBtn.addEventListener('click', loadTasks);
    startProgressBtn.addEventListener('click', startAllProgress);
    stopProgressBtn.addEventListener('click', stopAllProgress);
    delayNotificationBtn.addEventListener('click', showDelayedNotification);
});
To-Do List Application

A clean and simple to-do list application built to demonstrate core front-end skills. This project was created as a job simulation for a Front-End Development Intern role and is built using only vanilla HTML, CSS, and JavaScript.

Features

Add Tasks: Quickly add new tasks using the input field.

Edit Tasks: Edit existing tasks directly in the list.

Delete Tasks: Remove tasks you no longer need.

Complete Tasks: Mark tasks as complete with a checkbox.

Task History: Completed tasks are moved to a separate "Completed Tasks" history section.

Responsive UI: The layout is clean and works on various screen sizes.

Task Counter: A live counter shows the number of pending tasks.

Technology Stack

HTML5: For the basic structure and content.

CSS3: For all styling, layout, and responsiveness.

JavaScript (ES6): For all application logic, including DOM manipulation and event handling.

How to Run

Clone or download the project folder.

Open the index.html file in any modern web browser (like Chrome, Firefox, or Edge).

File Structure

index.html: Contains the HTML structure of the application.

style.css: Provides all the styling for the user interface.

script.js: Manages all the application's functionality and interactivity.
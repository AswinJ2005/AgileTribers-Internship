document.addEventListener('DOMContentLoaded', () => {
    const taskInput = document.getElementById('task-input');
    const addTaskBtn = document.getElementById('add-task-btn');
    const taskList = document.getElementById('task-list');
    const completedTaskList = document.getElementById('completed-task-list');
    const taskCounter = document.getElementById('task-counter');
    const clearAllBtn = document.getElementById('clear-all-btn');
    const taskManager = document.getElementById('task-manager');

    addTaskBtn.addEventListener('click', addTask);
    taskInput.addEventListener('keydown', (event) => {
        if (event.key === 'Enter') {
            addTask();
        }
    });

    taskManager.addEventListener('click', handleTaskAction);
    clearAllBtn.addEventListener('click', clearAllTasks);

    function addTask() {
        const taskText = taskInput.value.trim();
        if (taskText === '') {
            alert('Please enter a task.');
            return;
        }

        const li = document.createElement('li');
        li.className = 'task-item';
        
        li.innerHTML = `
            <input type="checkbox" class="complete-checkbox" title="Mark as complete">
            <span class="task-text">${taskText}</span>
            <div class="task-actions">
                <button class="edit-btn" title="Edit Task">📝 Edit</button>
                <button class="delete-btn" title="Delete Task">🗑️ Delete</button>
            </div>
        `;
        
        taskList.appendChild(li);
        taskInput.value = '';
        taskInput.focus();
        updateTaskCounter();
    }

    function handleTaskAction(e) {
        const target = e.target;
        const taskItem = target.closest('.task-item');

        if (!taskItem) return;

        if (target.classList.contains('complete-checkbox')) {
            toggleTaskCompletion(taskItem);
        }

        if (target.classList.contains('delete-btn')) {
            taskItem.remove();
        }

        if (target.classList.contains('edit-btn')) {
            handleEditTask(target, taskItem);
        }
        updateTaskCounter();
    }

    function toggleTaskCompletion(taskItem) {
        const editBtn = taskItem.querySelector('.edit-btn');
        const checkbox = taskItem.querySelector('.complete-checkbox');

        if (checkbox.checked) {
            completedTaskList.appendChild(taskItem);
            editBtn.disabled = true;
        } else {
            taskList.appendChild(taskItem);
            editBtn.disabled = false;
        }
    }
    
    function handleEditTask(editButton, taskItem) {
        const taskTextSpan = taskItem.querySelector('.task-text');
        
        if (editButton.textContent.includes('Edit')) {
            const currentText = taskTextSpan.textContent;
            taskTextSpan.innerHTML = `<input type="text" class="edit-input" value="${currentText}">`;
            taskTextSpan.querySelector('.edit-input').focus();
            editButton.innerHTML = '💾 Save';
        } else {
            const editInput = taskItem.querySelector('.edit-input');
            if (editInput.value.trim()) {
                taskTextSpan.textContent = editInput.value;
            }
            editButton.innerHTML = '📝 Edit';
        }
    }
    
    function updateTaskCounter() {
        const pendingCount = taskList.children.length;
        taskCounter.textContent = `You have ${pendingCount} pending task${pendingCount !== 1 ? 's' : ''}.`;
    }

    function clearAllTasks() {
        if (confirm('Are you sure you want to clear ALL tasks (pending and completed)?')) {
            taskList.innerHTML = '';
            completedTaskList.innerHTML = '';
            updateTaskCounter();
        }
    }

    updateTaskCounter();
});
import React from 'react';
import UserList from './UserList';
import './style.css';

function App() {
  const users = [
    { name: 'Alice Smith', email: 'alicesmith@gmail.com', age: 28, role: 'Admin' },
    { name: 'Bob Johnson', email: 'bobjohnson@gmail.com', age: 35, role: 'Member' },
    { name: 'Charlie Brown', email: 'charliebrown@gmail.com', age: 22, role: 'Member' },
    { name: 'Diana Prince', email: 'dianaprince@gmail.com', age: 40, role: 'Guest' },
    { name: 'Eve Adams', email: 'eveadams@gmail.com', age: 17, role: 'Admin' },
    { name: 'Frank Wright', email: 'frankwright@gmail.com', age: 31, role: 'Member' },
  ];

  return (
    <div className="app-container">
      <header className="app-header">
        <h1>Dynamic User Directory</h1>
      </header>
      <main>
        <UserList users={users} />
      </main>
    </div>
  );
}

export default App;
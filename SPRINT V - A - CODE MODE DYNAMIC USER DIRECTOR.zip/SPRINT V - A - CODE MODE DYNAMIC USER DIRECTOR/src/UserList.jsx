import React from 'react';
import UserCard from './UserCard';

function UserList({ users }) {
  // If the users array is empty, render the fallback UI.
  if (!users || users.length === 0) {
    return <p className="fallback-message">No users found</p>;
  }

  // Otherwise, map over the users to render a card for each one.
  return (
    <div className="user-list-container">
      {users.map(user => (
        <UserCard
          key={user.email}
          name={user.name}
          email={user.email}
          age={user.age}
          role={user.role}
        />
      ))}
    </div>
  );
}

export default UserList;
Single Page Website Clone: AWS Educate

This project is a front-end development exercise to clone the visual appearance of the AWS Educate landing page.

Objective

The goal was to replicate the structure, layout, and design of a real-world webpage using only HTML and CSS, demonstrating skills in static web page creation.

Technology Stack

HTML5

CSS3

How to Use

Create a folder named images in the same directory as the project files.

Place all the necessary image assets inside the images folder.

Open the index.html file in your web browser to view the page.
// src/App.jsx

import { useState } from 'react';
import { BrowserRouter, Routes, Route, Navigate, useLocation, useParams } from 'react-router-dom';
import { Container, Box, Stepper, Step, StepLabel, Typography } from '@mui/material';

// --- V FIX IS HERE ---
// Import step components
import Step1 from './components/Step1.jsx';
import Step2 from './components/Step2.jsx';
import Step3 from './components/Step3.jsx';
import Review from './components/Review.jsx';
import ThankYou from './components/ThankYou.jsx';

const stepsConfig = [
    { path: '/step/1', label: 'Enter Name' },
    { path: '/step/2', label: 'Provide Rating' },
    { path: '/step/3', label: 'Enter Message' },
    { path: '/review', label: 'Review & Submit' }
];

// ... rest of the file is the same ...
// No need to change anything below this line

const FormStepper = () => {
    const location = useLocation();
    const activeStep = stepsConfig.findIndex(step => step.path === location.pathname);

    if (activeStep === -1) {
        return null;
    }

    return (
        <Stepper activeStep={activeStep} alternativeLabel sx={{ mb: 4 }}>
            {stepsConfig.map((step) => (
                <Step key={step.label}>
                    <StepLabel>{step.label}</StepLabel>
                </Step>
            ))}
        </Stepper>
    );
};

const StepRouter = (props) => {
    const { stepId } = useParams();

    switch (stepId) {
        case '1':
            return <Step1 {...props} />;
        case '2':
            return <Step2 {...props} />;
        case '3':
            return <Step3 {...props} />;
        default:
            return <Navigate to="/step/1" />;
    }
};

function App() {
    const initialFormData = {
        name: '',
        rating: null,
        message: '',
    };
    
    const [formData, setFormData] = useState(initialFormData);

    const resetForm = () => setFormData(initialFormData);
    
    const props = { formData, setFormData, resetForm };

    return (
        <BrowserRouter>
            <Container maxWidth="md" sx={{ mt: 5, mb: 5 }}>
                <Typography component="h1" variant="h4" align="center" gutterBottom>
                    Multi-Page Feedback Form
                </Typography>
                
                <FormStepper />
                
                <Box component="main" sx={{ p: 3, border: '1px solid #ddd', borderRadius: 2 }}>
                    <Routes>
                        <Route path="/step/:stepId" element={<StepRouter {...props} />} />
                        <Route path="/review" element={<Review {...props} />} />
                        <Route path="/thankyou" element={<ThankYou {...props} />} />
                        <Route path="/" element={<Navigate to="/step/1" />} />
                        <Route path="*" element={<Navigate to="/step/1" />} />
                    </Routes>
                </Box>
            </Container>
        </BrowserRouter>
    );
}

export default App;
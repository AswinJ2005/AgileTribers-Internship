// src/components/Step1.jsx

import { useNavigate } from 'react-router-dom';
import { Box, TextField, Button, Typography } from '@mui/material';

function Step1({ formData, setFormData }) {
    const navigate = useNavigate();

    const handleChange = (e) => {
        setFormData({ ...formData, name: e.target.value });
    };

    const handleNext = () => {
        navigate('/step/2');
    };

    const isNextDisabled = formData.name.trim() === '';

    return (
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 3 }}>
            <Typography variant="h5" component="h2">Step 1: Your Name</Typography>
            <TextField
                label="Name"
                variant="outlined"
                value={formData.name}
                onChange={handleChange}
                fullWidth
                required
                autoFocus
            />
            <Box sx={{ display: 'flex', justifyContent: 'flex-end' }}>
                <Button 
                    variant="contained" 
                    onClick={handleNext}
                    disabled={isNextDisabled}
                >
                    Next
                </Button>
            </Box>
        </Box>
    );
}

export default Step1;
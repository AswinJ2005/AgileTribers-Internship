// src/components/Step2.jsx

import { useNavigate } from 'react-router-dom';
import { Box, Button, Typography, Rating } from '@mui/material';

function Step2({ formData, setFormData }) {
    const navigate = useNavigate();

    const handleChange = (event, newValue) => {
        setFormData({ ...formData, rating: newValue });
    };
    
    const isNextDisabled = formData.rating === null || formData.rating === 0;

    return (
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 3 }}>
            <Typography variant="h5" component="h2">Step 2: Provide a Rating</Typography>
            <Box sx={{ display: 'flex', justifyContent: 'center' }}>
                <Rating
                    name="feedback-rating"
                    value={formData.rating}
                    onChange={handleChange}
                    size="large"
                />
            </Box>
            <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                <Button variant="outlined" onClick={() => navigate('/step/1')}>
                    Back
                </Button>
                <Button 
                    variant="contained" 
                    onClick={() => navigate('/step/3')}
                    disabled={isNextDisabled}
                >
                    Next
                </Button>
            </Box>
        </Box>
    );
}

export default Step2;
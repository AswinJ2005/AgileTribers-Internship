// src/components/ThankYou.jsx

import { useNavigate } from 'react-router-dom';
import { Box, Button, Typography } from '@mui/material';

function ThankYou({ resetForm }) {
    const navigate = useNavigate();

    const handleStartOver = () => {
        resetForm();
        navigate('/step/1');
    };

    return (
        <Box sx={{ textAlign: 'center', py: 4 }}>
            <Typography variant="h4" component="h2" gutterBottom>
                🎉 Thank You! 🎉
            </Typography>
            <Typography variant="body1" color="textSecondary" sx={{ mb: 4 }}>
                Your feedback has been submitted successfully.
            </Typography>
            <Button variant="contained" onClick={handleStartOver}>
                Submit Another Response
            </Button>
        </Box>
    );
}

export default ThankYou;
// src/components/Review.jsx

import { useNavigate } from 'react-router-dom';
import { Box, Button, Typography, Paper, List, ListItem, ListItemText, Rating } from '@mui/material';

function Review({ formData }) {
    const navigate = useNavigate();

    const handleSubmit = () => {
        console.log('Submitting Feedback:', formData);
        navigate('/thankyou');
    };

    return (
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 3 }}>
            <Typography variant="h5" component="h2">Step 4: Review Your Feedback</Typography>
            <Paper elevation={2} sx={{ p: 2 }}>
                <List>
                    <ListItem>
                        <ListItemText primary="Name" secondary={formData.name || 'Not Provided'} />
                    </ListItem>
                    <ListItem>
                        <ListItemText 
                            primary="Rating" 
                            secondary={
                                <Rating value={formData.rating} readOnly />
                            }
                        />
                    </ListItem>
                    <ListItem>
                        <ListItemText 
                            primary="Message" 
                            secondary={formData.message || 'Not Provided'}
                            secondaryTypographyProps={{ style: { whiteSpace: 'pre-wrap' } }} 
                        />
                    </ListItem>
                </List>
            </Paper>
            <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                <Button variant="outlined" onClick={() => navigate('/step/3')}>
                    Back
                </Button>
                <Button variant="contained" color="primary" onClick={handleSubmit}>
                    Submit
                </Button>
            </Box>
        </Box>
    );
}

export default Review;
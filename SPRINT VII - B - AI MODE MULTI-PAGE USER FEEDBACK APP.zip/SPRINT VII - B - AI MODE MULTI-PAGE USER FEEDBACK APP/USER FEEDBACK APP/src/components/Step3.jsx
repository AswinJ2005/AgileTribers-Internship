// src/components/Step3.jsx

import { useNavigate } from 'react-router-dom';
import { Box, TextField, Button, Typography } from '@mui/material';

function Step3({ formData, setFormData }) {
    const navigate = useNavigate();

    const handleChange = (e) => {
        setFormData({ ...formData, message: e.target.value });
    };

    return (
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 3 }}>
            <Typography variant="h5" component="h2">Step 3: Your Message</Typography>
            <TextField
                label="Message (Optional)"
                variant="outlined"
                value={formData.message}
                onChange={handleChange}
                fullWidth
                multiline
                rows={4}
            />
            <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                <Button variant="outlined" onClick={() => navigate('/step/2')}>
                    Back
                </Button>
                <Button variant="contained" onClick={() => navigate('/review')}>
                    Review
                </Button>
            </Box>
        </Box>
    );
}

export default Step3;
// File: src/BookCard.jsx

import React from 'react';
import { Card, CardContent, CardMedia, Typography, Grid, Box } from '@mui/material';

const BookCard = ({ book }) => {
  // Construct the image URL. Use a placeholder if no cover ID is available.
  const coverImageUrl = book.cover_i 
    ? `https://covers.openlibrary.org/b/id/${book.cover_i}-M.jpg` 
    : 'https://via.placeholder.com/128x192.png?text=No+Cover';
    
  return (
    <Grid item xs={12} sm={6} md={4} lg={3}>
      <Card 
        sx={{ 
          height: '100%', 
          display: 'flex', 
          flexDirection: 'column',
          transition: 'transform 0.2s ease-in-out',
          '&:hover': {
            transform: 'scale(1.03)',
            boxShadow: 6, // Add a more prominent shadow on hover
          }
        }}
      >
        <CardMedia
          component="img"
          sx={{ 
            // 3:4 aspect ratio for book covers
            aspectRatio: '3 / 4',
            objectFit: 'cover'
          }}
          image={coverImageUrl}
          alt={`Cover for ${book.title}`}
        />
        <CardContent sx={{ flexGrow: 1 }}>
          <Typography gutterBottom variant="h6" component="h2" noWrap>
            {book.title}
          </Typography>
          <Typography variant="body2" color="text.secondary">
            {/* API returns author_name as an array, join them for display */}
            {book.author_name ? book.author_name.join(', ') : 'Unknown Author'}
          </Typography>
        </CardContent>
      </Card>
    </Grid>
  );
};

export default BookCard;
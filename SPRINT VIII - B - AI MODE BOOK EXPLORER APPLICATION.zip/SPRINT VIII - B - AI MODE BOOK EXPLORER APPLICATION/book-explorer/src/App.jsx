// File: src/App.jsx

import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import { 
  // Core Components
  Container, TextField, Grid, Typography, CircularProgress, Box, AppBar, Toolbar, Card, CardContent, CardMedia,
  // Modal Components
  Modal, Fade, Backdrop, 
  // Styling & Theme Components
  Skeleton, CssBaseline, ThemeProvider, createTheme, IconButton
} from '@mui/material';
// Icons for the theme toggle
import Brightness4Icon from '@mui/icons-material/Brightness4';
import Brightness7Icon from '@mui/icons-material/Brightness7';
import { fetchMockBooks } from './mockApi';

// The other components (BookDetailsModal, BookCard, SkeletonCard) remain unchanged
// and can be kept inside this file for simplicity.

const BookDetailsModal = ({ book, open, onClose }) => {
  if (!book) return null;
  const style = {
    position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -50%)',
    width: 400, bgcolor: 'background.paper', border: '2px solid #000', boxShadow: 24, p: 4,
  };
  return (
    <Modal open={open} onClose={onClose} closeAfterTransition BackdropComponent={Backdrop} BackdropProps={{ timeout: 500 }}>
      <Fade in={open}>
        <Box sx={style}>
          <Typography variant="h5" component="h2">{book.title}</Typography>
          <Typography sx={{ mt: 2 }}><strong>Authors:</strong> {book.author_name ? book.author_name.join(', ') : 'N/A'}</Typography>
          <Typography sx={{ mt: 1 }}><strong>First Published:</strong> {book.first_publish_year || 'N/A'}</Typography>
        </Box>
      </Fade>
    </Modal>
  );
};

const BookCard = React.forwardRef(({ book, onClick }, ref) => {
  const coverImageUrl = book.cover_i ? `https://covers.openlibrary.org/b/id/${book.cover_i}-M.jpg` : 'https://via.placeholder.com/128x192.png?text=No+Cover';
  return (
    <Grid item xs={12} sm={6} md={4} lg={3} ref={ref}>
      <Card onClick={onClick} sx={{ height: '100%', display: 'flex', flexDirection: 'column', cursor: 'pointer', transition: 'transform 0.2s ease-in-out', '&:hover': { transform: 'scale(1.03)', boxShadow: 6, } }}>
        <CardMedia component="img" sx={{ aspectRatio: '3 / 4', objectFit: 'cover' }} image={coverImageUrl} alt={`Cover for ${book.title}`} />
        <CardContent sx={{ flexGrow: 1, display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
          <Typography gutterBottom variant="h6" component="h2" noWrap title={book.title}>{book.title}</Typography>
          <Typography variant="body2" color="text.secondary">{book.author_name ? book.author_name.join(', ') : 'Unknown Author'}</Typography>
        </CardContent>
      </Card>
    </Grid>
  );
});

const SkeletonCard = () => (
  <Grid item xs={12} sm={6} md={4} lg={3}>
    <Skeleton variant="rectangular" sx={{ aspectRatio: '3 / 4' }} />
    <Skeleton /><Skeleton width="60%" />
  </Grid>
);

// ======================================================================
// The Main App Component
// ======================================================================
function App() {
  // --- ADVANCED FEATURE: DARK MODE ---
  // 1. State to manage the theme mode ('light' or 'dark')
  const [mode, setMode] = useState(() => {
    const savedMode = localStorage.getItem('themeMode');
    const prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
    return savedMode || (prefersDark ? 'dark' : 'light');
  });

  // 2. useEffect to save the theme preference to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem('themeMode', mode);
  }, [mode]);
  
  // 3. useMemo to create the theme object. It only recalculates when 'mode' changes.
  const theme = useMemo(
    () => createTheme({
      palette: {
        mode, // This single property switches MUI components to the chosen theme
      },
    }),
    [mode],
  );

  const toggleTheme = () => {
    setMode((prevMode) => (prevMode === 'light' ? 'dark' : 'light'));
  };

  // State for search and books
  const [searchTerm, setSearchTerm] = useState('the lord of the rings');
  const [books, setBooks] = useState([]);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(false);
  const [hasMore, setHasMore] = useState(true);
  const [selectedBook, setSelectedBook] = useState(null);

  const debounceTimeoutRef = useRef(null);
  const observer = useRef();

  const lastBookElementRef = useCallback(node => {
    if (loading) return;
    if (observer.current) observer.current.disconnect();
    observer.current = new IntersectionObserver(entries => {
      if (entries[0].isIntersecting && hasMore) setPage(prevPage => prevPage + 1);
    });
    if (node) observer.current.observe(node);
  }, [loading, hasMore]);

  useEffect(() => {
    if (page === 1) setLoading(true);
    fetchMockBooks(searchTerm, page).then(data => {
      setBooks(prevBooks => (page === 1 ? data.docs : [...prevBooks, ...data.docs]));
      setHasMore(data.numFound > page * 8);
      if (page === 1) setLoading(false);
    });
  }, [searchTerm, page]);

  const handleSearch = (event) => {
    const newSearchTerm = event.target.value;
    if (debounceTimeoutRef.current) clearTimeout(debounceTimeoutRef.current);
    debounceTimeoutRef.current = setTimeout(() => {
      setSearchTerm(newSearchTerm);
      setPage(1);
      setBooks([]);
    }, 500);
  };

  const handleOpenModal = (book) => setSelectedBook(book);
  const handleCloseModal = () => setSelectedBook(null);

  // The entire application is now wrapped in ThemeProvider
  return (
    <ThemeProvider theme={theme}>
      <CssBaseline /> {/* Applies the theme's background color and resets CSS */}
      <AppBar position="sticky">
        <Toolbar>
          <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
            Book Explorer Application
          </Typography>
          {/* --- 4. The UI Button to toggle the theme --- */}
          <IconButton sx={{ ml: 1 }} onClick={toggleTheme} color="inherit">
            {theme.palette.mode === 'dark' ? <Brightness7Icon /> : <Brightness4Icon />}
          </IconButton>
        </Toolbar>
      </AppBar>

      <BookDetailsModal book={selectedBook} open={!!selectedBook} onClose={handleCloseModal} />

      <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
        <Box sx={{ mb: 4 }}>
          <TextField fullWidth label="Search for books by title" variant="outlined" defaultValue="the lord of the rings" onChange={handleSearch} />
        </Box>
        <Grid container spacing={4}>
          {loading && page === 1 ? (
            Array.from(new Array(8)).map((_, index) => <SkeletonCard key={index} />)
          ) : (
            books.map((book, index) => (
              <BookCard
                book={book}
                key={`${book.key}-${index}`}
                onClick={() => handleOpenModal(book)}
                ref={books.length === index + 1 ? lastBookElementRef : null}
              />
            ))
          )}
        </Grid>
        
        {!loading && books.length === 0 && searchTerm && (
          <Typography align="center" sx={{ mt: 5 }}>No books found for "{searchTerm}". Please try a different search.</Typography>
        )}
        {loading && page > 1 && (<Box sx={{ display: 'flex', justifyContent: 'center', mt: 4 }}><CircularProgress /></Box>)}
      </Container>
    </ThemeProvider>
  );
}

export default App;
// File: src/mockApi.js

import { mockBooks } from './mockData.js'; // This file now depends on the one you just created

const PAGE_SIZE = 8; 

export const fetchMockBooks = (query, page) => {
  return new Promise((resolve) => {
    setTimeout(() => {
      if (!query) {
        resolve({ docs: [], numFound: 0 });
        return;
      }
      const filteredBooks = mockBooks.filter(book => 
        book.title.toLowerCase().includes(query.toLowerCase())
      );
      const startIndex = (page - 1) * PAGE_SIZE;
      const paginatedBooks = filteredBooks.slice(startIndex, startIndex + PAGE_SIZE);
      resolve({
        docs: paginatedBooks,
        numFound: filteredBooks.length
      });
    }, 500);
  });
};
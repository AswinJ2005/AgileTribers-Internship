// File: src/api.js

/**
 * Fetches books from the Open Library API based on a search query and page number.
 * @param {string} query - The search term for the books.
 * @param {number} page - The page number of the results to fetch.
 * @returns {Promise<object>} A promise that resolves to the API response data.
 */
export const fetchBooks = async (query, page) => {
  // If the query is empty, return an empty result set immediately.
  if (!query) {
    return { docs: [], numFound: 0 };
  }

  try {
    const response = await fetch(`https://openlibrary.org/search.json?q=${encodeURIComponent(query)}&page=${page}`);
    
    // Check if the network response was successful
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const data = await response.json();
    return data;
  } catch (error) {
    console.error("Failed to fetch books:", error);
    // Propagate the error to be handled by the calling component
    throw error;
  }
};
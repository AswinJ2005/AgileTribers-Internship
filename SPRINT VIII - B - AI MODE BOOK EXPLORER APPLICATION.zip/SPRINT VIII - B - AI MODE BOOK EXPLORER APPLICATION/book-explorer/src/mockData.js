// File: src/mockData.js

export const mockBooks = [
  { key: '/works/OL45883W', title: 'The Lord of the Rings', author_name: ['J.R.R. Tolkien'], cover_i: 10580103, first_publish_year: 1954 },
  { key: '/works/OL27448W', title: 'The Hobbit', author_name: ['J.R.R. Tolkien'], cover_i: 8264455, first_publish_year: 1937 },
  { key: '/works/OL1953259W', title: 'A Game of Thrones', author_name: ['George R.R. Martin'], cover_i: 12903173, first_publish_year: 1996 },
  { key: '/works/OL28258W', title: 'Dune', author_name: ['Frank Herbert'], cover_i: 9269962, first_publish_year: 1965 },
  { key: '/works/OL150917W', title: '1984', author_name: ['George Orwell'], cover_i: 13083654, first_publish_year: 1949 },
  { key: '/works/OL17906W', title: 'Brave New World', author_name: ['Aldous Huxley'], cover_i: 10058428, first_publish_year: 1932 },
  { key: '/works/OL67694W', title: 'Fahrenheit 451', author_name: ['Ray Bradbury'], cover_i: 12952864, first_publish_year: 1953 },
  { key: '/works/OL34579W', title: 'The Catcher in the Rye', author_name: ['J.D. Salinger'], cover_i: 8415785, first_publish_year: 1951 },
  { key: '/works/OL24345W', title: 'To Kill a Mockingbird', author_name: ['Harper Lee'], cover_i: 13200720, first_publish_year: 1960 },
  { key: '/works/OL12187W', title: 'Pride and Prejudice', author_name: ['Jane Austen'], cover_i: 10459529, first_publish_year: 1813 },
  { key: '/works/OL27354W', title: 'The Great Gatsby', author_name: ['F. Scott Fitzgerald'], cover_i: 13203910, first_publish_year: 1925 },
  { key: '/works/OL28328W', title: 'Moby Dick', author_name: ['Herman Melville'], cover_i: 7215284, first_publish_year: 1851 },
  { key: '/works/OL28256W', title: 'Foundation', author_name: ['Isaac Asimov'], cover_i: 12852174, first_publish_year: 1951 },
  { key: '/works/OL6990430W', title: 'The Martian', author_name: ['Andy Weir'], cover_i: 8406522, first_publish_year: 2011 },
  { key: '/works/OL26114W', title: 'Enders Game', author_name: ['Orson Scott Card'], cover_i: 7393457, first_publish_year: 1985 },
];
document.addEventListener('DOMContentLoaded', () => {
    // --- DOM Elements ---
    const loadTasksBtn = document.getElementById('loadTasksBtn');
    const startProgressBtn = document.getElementById('startProgressBtn');
    const stopProgressBtn = document.getElementById('stopProgressBtn');
    const delayNotificationBtn = document.getElementById('delayNotificationBtn');
    const exportCsvBtn = document.getElementById('exportCsvBtn');
    const searchInput = document.getElementById('searchInput');
    const statusFilter = document.getElementById('statusFilter');
    const taskListDiv = document.getElementById('taskList');
    const notificationsPanel = document.getElementById('notificationsPanel');

    // --- State ---
    let tasks = [];
    let intervalIds = {};

    const FAKE_TASK_DATA = [
        { id: 1, name: 'Uploading files to server', priority: 'High' },
        { id: 2, name: 'Processing video data', priority: 'Medium' },
        { id: 3, name: 'Generating weekly reports', priority: 'Medium' },
        { id: 4, name: 'Backing up database', priority: 'Low' },
    ];

    // --- Core Functions ---

    const fetchFakeTasks = () => {
        return new Promise((resolve) => {
            setTimeout(() => {
                resolve(JSON.parse(JSON.stringify(FAKE_TASK_DATA))); // Deep copy
            }, 1000);
        });
    };

    const loadTasks = async () => {
        taskListDiv.innerHTML = '<p>Loading...</p>';
        try {
            const fetchedTasks = await fetchFakeTasks();
            tasks = fetchedTasks.map(task => ({
                ...task,
                progress: 0,
                status: 'Pending'
            }));
            applyFiltersAndRender();
            addNotification("Tasks loaded successfully.");
        } catch (error) {
            taskListDiv.innerHTML = '<p>Failed to load tasks. Please try again.</p>';
            console.error('Error fetching tasks:', error);
        }
    };

    const renderTasks = (tasksToRender) => {
        taskListDiv.innerHTML = '';
        if (tasksToRender.length === 0) {
            taskListDiv.innerHTML = '<p>No tasks match your criteria.</p>';
            return;
        }

        tasksToRender.forEach(task => {
            const taskCard = document.createElement('div');
            taskCard.className = `task-card status-${task.status.toLowerCase().replace(' ', '-')}`;
            taskCard.id = `task-${task.id}`;
            taskCard.innerHTML = `
                <div class="task-header">
                    <div class="task-name-container">
                        <span class="task-priority priority-${task.priority.toLowerCase()}">${task.priority}</span>
                        <div class="task-name">${task.name}</div>
                    </div>
                    <div class="task-status">${task.status}</div>
                </div>
                <div class="progress-container">
                    <div class="progress-bar" style="width: ${task.progress}%;">${task.progress}%</div>
                </div>
                <div class="task-actions">
                    <button class="edit-btn" data-id="${task.id}">Edit</button>
                    <button class="delete-btn" data-id="${task.id}">Delete</button>
                </div>
            `;
            taskListDiv.appendChild(taskCard);
        });
    };

    const applyFiltersAndRender = () => {
        let filteredTasks = [...tasks];
        const searchTerm = searchInput.value.toLowerCase();
        const status = statusFilter.value;

        // Filter by search term
        if (searchTerm) {
            filteredTasks = filteredTasks.filter(task => task.name.toLowerCase().includes(searchTerm));
        }

        // Filter by status
        if (status !== 'all') {
            filteredTasks = filteredTasks.filter(task => task.status === status);
        }

        renderTasks(filteredTasks);
    };

    const updateTaskUI = (taskId) => {
        const task = tasks.find(t => t.id === taskId);
        if (!task) return;

        const taskCard = document.getElementById(`task-${taskId}`);
        if (!taskCard) return; // Might have been filtered out

        const progressBar = taskCard.querySelector('.progress-bar');
        const taskStatus = taskCard.querySelector('.task-status');
        
        progressBar.style.width = `${task.progress}%`;
        progressBar.textContent = `${task.progress}%`;
        taskStatus.textContent = task.status;
        
        taskCard.className = `task-card status-${task.status.toLowerCase().replace(' ', '-')}`;
    };

    // --- Task Progress Control ---

    const startAllProgress = () => {
        tasks.forEach(task => {
            if (task.progress < 100 && !intervalIds[task.id]) {
                task.status = 'In Progress';
                updateTaskUI(task.id);

                intervalIds[task.id] = setInterval(() => {
                    task.progress += Math.floor(Math.random() * 5) + 5; // random increment

                    if (task.progress >= 100) {
                        task.progress = 100;
                        task.status = 'Completed';
                        clearInterval(intervalIds[task.id]);
                        delete intervalIds[task.id];
                        addNotification(`Task "${task.name}" completed!`);
                    }
                    updateTaskUI(task.id);
                }, 800);
            }
        });
        applyFiltersAndRender();
    };
    
    const stopAllProgress = () => {
        Object.keys(intervalIds).forEach(taskId => {
            clearInterval(intervalIds[taskId]);
            const task = tasks.find(t => t.id == taskId);
            if (task && task.status === 'In Progress') {
                task.status = 'Stopped';
                addNotification(`Task "${task.name}" stopped.`);
                updateTaskUI(task.id);
            }
            delete intervalIds[taskId];
        });
        applyFiltersAndRender();
    };

    // --- Task Actions (Edit/Delete) ---

    const handleTaskActions = (e) => {
        const target = e.target;
        const taskId = parseInt(target.dataset.id, 10);

        if (target.classList.contains('delete-btn')) {
            if (confirm("Are you sure you want to delete this task?")) {
                tasks = tasks.filter(t => t.id !== taskId);
                clearInterval(intervalIds[taskId]);
                delete intervalIds[taskId];
                applyFiltersAndRender();
                addNotification(`Task ID ${taskId} deleted.`);
            }
        }

        if (target.classList.contains('edit-btn')) {
            const task = tasks.find(t => t.id === taskId);
            const newName = prompt("Enter new task name:", task.name);
            if (newName && newName.trim() !== '') {
                task.name = newName.trim();
                applyFiltersAndRender();
                addNotification(`Task "${task.name}" updated.`);
            }
        }
    };
    
    // --- Notifications & Export ---

    const showDelayedNotification = () => {
        addNotification("Notification scheduled...");
        setTimeout(() => {
            addNotification("This is your delayed message!");
        }, 3000);
    };

    const addNotification = (message) => {
        const p = document.createElement('p');
        p.textContent = `[${new Date().toLocaleTimeString()}] ${message}`;
        notificationsPanel.prepend(p);
    };

    const exportTasksToCSV = () => {
        if (tasks.length === 0) {
            addNotification("No tasks to export.");
            return;
        }

        const headers = ['ID', 'Name', 'Status', 'Progress (%)', 'Priority'];
        const csvRows = [headers.join(',')];

        tasks.forEach(task => {
            const values = [
                task.id,
                `"${task.name.replace(/"/g, '""')}"`, // Handle quotes in names
                task.status,
                task.progress,
                task.priority
            ];
            csvRows.push(values.join(','));
        });

        const csvString = csvRows.join('\n');
        const blob = new Blob([csvString], { type: 'text/csv;charset=utf-8;' });
        
        const link = document.createElement('a');
        const url = URL.createObjectURL(blob);
        link.setAttribute('href', url);
        link.setAttribute('download', 'task-report.csv');
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        addNotification("Task report exported as CSV.");
    };


    // --- Event Listeners ---
    loadTasksBtn.addEventListener('click', loadTasks);
    startProgressBtn.addEventListener('click', startAllProgress);
    stopProgressBtn.addEventListener('click', stopAllProgress);
    delayNotificationBtn.addEventListener('click', showDelayedNotification);
    exportCsvBtn.addEventListener('click', exportTasksToCSV);
    searchInput.addEventListener('input', applyFiltersAndRender);
    statusFilter.addEventListener('change', applyFiltersAndRender);
    taskListDiv.addEventListener('click', handleTaskActions);
});
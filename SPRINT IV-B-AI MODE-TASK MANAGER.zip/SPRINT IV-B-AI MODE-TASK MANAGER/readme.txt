🚀 Async Task Manager

A modern, single-page web application to manage and track the progress of asynchronous tasks. Built with vanilla JavaScript, this project demonstrates key concepts like async/await, dynamic DOM manipulation, and real-time user feedback.

✨ Features

⏳ Asynchronous Operations: Load tasks and simulate their progress without blocking the UI.

🚦 Task Priority: Assign High, Medium, or Low priority to tasks, with clear color indicators.

✏️ Dynamic Task Management: Easily edit task names or delete tasks with the click of a button.

🔍 Filter & Search: Instantly find tasks by searching for their name or filtering by their status (e.g., In Progress, Completed).

📊 Smooth Progress Bars: Watch tasks progress with satisfying, animated bars.

🔔 Real-time Notifications: Get instant feedback on actions like loading, completing, or deleting tasks.

📄 Export to CSV: Download a summary of all your tasks as a .csv file for reporting.

💻 Technologies Used

HTML
CSS
JavaScript 

▶️ How to Run

Getting started is as simple as it gets!

Download the index.html, style.css, and script.js files.

Place them all in the same folder.

Open the index.html file in your favorite web browser (like Chrome, Firefox, or Edge).

That's it! You're ready to manage your tasks. 🎉
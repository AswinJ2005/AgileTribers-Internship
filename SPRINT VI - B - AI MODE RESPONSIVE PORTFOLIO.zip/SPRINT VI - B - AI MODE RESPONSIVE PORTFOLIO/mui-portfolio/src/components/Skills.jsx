import React from 'react';
import { Box, Typography, Container, Chip, Paper } from '@mui/material';

const skills = [
  'React', 'JavaScript (ES6+)', 'HTML5', 'CSS3', 'Material-UI (MUI)',
  'Responsive Design', 'Node.js', 'Express', 'Git', 'GitHub', 'REST APIs', 'Redux'
];

const Skills = () => {
  return (
    <Box id="skills" sx={{ py: 8 }}>
      <Container maxWidth="md">
        <Typography variant="h4" align="center" gutterBottom>
          Professional Skills
        </Typography>
        <Paper
          elevation={3}
          sx={{
            display: 'flex',
            justifyContent: 'center',
            flexWrap: 'wrap',
            listStyle: 'none',
            p: 2,
            m: 0,
            gap: 1.5,
          }}
          component="ul"
        >
          {skills.map((skill) => (
            <li key={skill}>
              <Chip label={skill} color="primary" variant="outlined" />
            </li>
          ))}
        </Paper>
      </Container>
    </Box>
  );
};

export default Skills;
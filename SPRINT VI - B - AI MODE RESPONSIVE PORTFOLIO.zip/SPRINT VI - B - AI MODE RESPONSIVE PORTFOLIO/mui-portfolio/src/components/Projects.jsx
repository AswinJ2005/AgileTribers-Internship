import React from 'react';
import { Box, Typography, Container, Grid, Card, CardContent, CardActions, Button, CardMedia } from '@mui/material';
import OpenInNewIcon from '@mui/icons-material/OpenInNew';

const projectsData = [
  {
    title: 'E-commerce Platform',
    description: 'A full-featured e-commerce site built with React, complex state management, and API integration.',
    image: 'https://images.unsplash.com/photo-1522199755839-a2bacb67c546?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2072&q=80',
  },
  {
    title: 'Task Management App',
    description: 'A sleek and intuitive task manager that helps users organize their daily tasks efficiently using a clean UI.',
    image: 'https://images.unsplash.com/photo-1599388301142-f9b88998491c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1853&q=80',
  },
  {
    title: 'Personal Portfolio',
    description: 'A responsive portfolio page (like this one!) to showcase skills and projects to employers.',
    image: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2072&q=80',
  },
];

const Projects = () => {
  return (
    <Box id="projects" sx={{ py: 8 }}>
      <Container maxWidth="lg">
        <Typography variant="h4" align="center" gutterBottom>
          Projects Showcase
        </Typography>
        <Grid container spacing={4} sx={{ mt: 2 }}>
          {projectsData.map((project) => (
            <Grid item key={project.title} xs={12} sm={6} md={4}>
              <Card 
                sx={{ 
                  height: '100%', 
                  display: 'flex', 
                  flexDirection: 'column',
                  transition: 'transform 0.3s, box-shadow 0.3s',
                  '&:hover': {
                    transform: 'scale(1.03)',
                    boxShadow: 6,
                  },
                }}
              >
                <CardMedia component="div" sx={{ pt: '56.25%' }} image={project.image} />
                <CardContent sx={{ flexGrow: 1 }}>
                  <Typography gutterBottom variant="h5" component="h2">{project.title}</Typography>
                  <Typography color="text.secondary">{project.description}</Typography>
                </CardContent>
                <CardActions>
                  <Button size="small" startIcon={<OpenInNewIcon />}>View Project</Button>
                </CardActions>
              </Card>
            </Grid>
          ))}
        </Grid>
      </Container>
    </Box>
  );
};

export default Projects;
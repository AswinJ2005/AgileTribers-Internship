import React from 'react';
import { Box, Typography, Container, TextField, Button, Grid } from '@mui/material';

const Contact = () => {
  return (
    <Box id="contact" sx={{ py: 8, backgroundColor: 'background.paper' }}>
      <Container maxWidth="md">
        <Typography variant="h4" align="center" gutterBottom>
          Contact Me
        </Typography>
        <Box component="form" noValidate autoComplete="off" sx={{ mt: 3 }}>
          <Grid container spacing={2}>
            <Grid item xs={12} sm={6}>
              <TextField required fullWidth id="name" label="Name" name="name" />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField required fullWidth id="email" label="Email Address" name="email" />
            </Grid>
            <Grid item xs={12}>
              <TextField required fullWidth id="message" label="Message" name="message" multiline rows={4} />
            </Grid>
          </Grid>
          <Button type="submit" fullWidth variant="contained" sx={{ mt: 3, mb: 2 }}>
            Send Message
          </Button>
        </Box>
      </Container>
    </Box>
  );
};

export default Contact;
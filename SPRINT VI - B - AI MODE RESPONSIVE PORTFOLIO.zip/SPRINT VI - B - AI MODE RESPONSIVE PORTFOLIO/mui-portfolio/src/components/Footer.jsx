import React from 'react';
import { Box, Typography, Container, IconButton, Stack } from '@mui/material';
import GitHubIcon from '@mui/icons-material/GitHub';
import LinkedInIcon from '@mui/icons-material/LinkedIn';
import TwitterIcon from '@mui/icons-material/Twitter';

const Footer = () => {
  return (
    <Box 
      component="footer" 
      sx={{ 
        py: 3, 
        px: 2, 
        mt: 'auto',
        backgroundColor: (theme) =>
          theme.palette.mode === 'light'
            ? theme.palette.grey[200]
            : theme.palette.grey[800],
      }}
    >
      <Container maxWidth="sm">
        <Stack direction="row" justifyContent="center" spacing={1} mb={2}>
          <IconButton href="https://github.com" target="_blank" color="inherit">
            <GitHubIcon />
          </IconButton>
          <IconButton href="https://linkedin.com" target="_blank" color="inherit">
            <LinkedInIcon />
          </IconButton>
          <IconButton href="https://twitter.com" target="_blank" color="inherit">
            <TwitterIcon />
          </IconButton>
        </Stack>
        <Typography variant="body2" color="text.secondary" align="center">
          {'Copyright © '}
          Aswin J {new Date().getFullYear()}
          {'.'}
        </Typography>
      </Container>
    </Box>
  );
};

export default Footer;
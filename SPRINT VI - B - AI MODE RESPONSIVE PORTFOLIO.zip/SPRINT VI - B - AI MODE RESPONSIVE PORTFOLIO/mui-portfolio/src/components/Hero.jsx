import React from 'react';
import { Box, Typography, Button, Container } from '@mui/material';
import { TypeAnimation } from 'react-type-animation';
import DownloadIcon from '@mui/icons-material/Download';

const Hero = () => {
  const handleScroll = (elementId) => {
    const element = document.getElementById(elementId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <Box 
      id="home"
      sx={{ 
        pt: 8, 
        pb: 6, 
        minHeight: '80vh', 
        display: 'flex', 
        alignItems: 'center',
        justifyContent: 'center',
        textAlign: 'center'
      }}
    >
      <Container maxWidth="md">
        <Typography 
          component="h1" 
          variant="h2" 
          gutterBottom
        >
          Aswin J
        </Typography>
        <TypeAnimation
          sequence={[
            'A Passionate Front-End Developer', 1000,
            'A React & MUI Specialist', 1000,
            'A Creative Problem Solver', 1000,
            'Ready to Build Amazing Things', 1000,
          ]}
          wrapper="span"
          speed={50}
          style={{
            fontSize: '1.5em',
            display: 'inline-block',
            color: 'text.secondary',
            minHeight: '50px',
          }}
          repeat={Infinity}
        />
        <Box sx={{ mt: 4 }}>
          <Button 
            variant="contained" 
            color="primary" 
            size="large" 
            sx={{ mr: 2 }} 
            onClick={() => handleScroll('contact')}
          >
            Hire Me
          </Button>
          <Button
            component="a"
            href="/resume.pdf"
            download="AswinJ_Resume.pdf"
            variant="outlined"
            color="primary"
            size="large"
            startIcon={<DownloadIcon />}
          >
            Download CV
          </Button>
        </Box>
      </Container>
    </Box>
  );
};

export default Hero;
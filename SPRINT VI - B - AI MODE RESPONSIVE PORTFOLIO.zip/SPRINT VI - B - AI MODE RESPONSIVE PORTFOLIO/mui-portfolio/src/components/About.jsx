import React from 'react';
import { Box, Typography, Container, Card, CardContent } from '@mui/material';

const About = () => {
  return (
    <Box id="about" sx={{ py: 8, backgroundColor: 'background.paper' }}>
      <Container maxWidth="md">
        <Typography variant="h4" align="center" gutterBottom>
          About Me
        </Typography>
        <Card>
          <CardContent>
            <Typography variant="body1" color="text.secondary">
              I am a dedicated front-end developer with a keen eye for detail and a love for creating intuitive and responsive user interfaces. My expertise lies in building dynamic web applications with React and leveraging component libraries like Material UI to ensure consistency and speed up development. I thrive in collaborative environments and am always eager to learn new technologies and improve my craft.
            </Typography>
          </CardContent>
        </Card>
      </Container>
    </Box>
  );
};

export default About;
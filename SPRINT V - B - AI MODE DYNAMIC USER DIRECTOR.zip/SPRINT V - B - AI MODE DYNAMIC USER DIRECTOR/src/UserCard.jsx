import React from 'react';

function UserCard({ name, email, age, role }) {
  // Determine the role badge's CSS class based on the role prop.
  const getRoleBadgeClass = () => {
    const roleLower = role.toLowerCase();
    switch (roleLower) {
      case 'admin':
        return 'role-badge admin';
      case 'member':
        return 'role-badge member';
      case 'guest':
        return 'role-badge guest';
      default:
        return 'role-badge';
    }
  };

  return (
    <div className="user-card">
      <div className="user-details">
        <h2>{name}</h2>
        <p><strong>Email:</strong> {email}</p>
        <p><strong>Age:</strong> {age}</p>
      </div>
      <div className="user-role-container">
        <span className={getRoleBadgeClass()}>{role}</span>
      </div>
    </div>
  );
}

export default UserCard;
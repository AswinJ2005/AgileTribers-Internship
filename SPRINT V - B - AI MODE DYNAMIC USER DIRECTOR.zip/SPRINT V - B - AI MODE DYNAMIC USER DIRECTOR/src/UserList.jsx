import React from 'react';
import UserCard from './UserCard';

function UserList({ users, roles, currentFilter, onFilterChange }) {
  return (
    <>
      <div className="filter-container">
        <label htmlFor="role-filter">Filter by Role:</label>
        <select id="role-filter" value={currentFilter} onChange={onFilterChange}>
          {roles.map(role => (
            <option key={role} value={role}>{role}</option>
          ))}
        </select>
      </div>

      {/* If the users array is empty, render the fallback UI. */}
      {!users || users.length === 0 ? (
        <p className="fallback-message">No users found for this role</p>
      ) : (
        <div className="user-list-container">
          {users.map(user => (
            <UserCard
              key={user.email}
              name={user.name}
              email={user.email}
              age={user.age}
              role={user.role}
            />
          ))}
        </div>
      )}
    </>
  );
}

export default UserList;
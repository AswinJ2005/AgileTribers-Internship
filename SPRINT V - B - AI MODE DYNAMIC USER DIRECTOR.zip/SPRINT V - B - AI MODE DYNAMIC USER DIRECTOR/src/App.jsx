import React, { useState, useEffect } from 'react';
import UserList from './UserList';
import './style.css';

function App() {
  const users = [
    { name: 'Alice Smith', email: 'alicesmith@gmail.com', age: 28, role: 'Admin' },
    { name: 'Bob Johnson', email: 'bobjohnson@gmail.com', age: 35, role: 'Member' },
    { name: 'Charlie Brown', email: 'charliebrown@gmail.com', age: 22, role: 'Member' },
    { name: 'Diana Prince', email: 'dianaprince@gmail.com', age: 40, role: 'Guest' },
    { name: 'Eve Adams', email: 'eveadams@gmail.com', age: 17, role: 'Admin' },
    { name: 'Frank Wright', email: 'frankwright@gmail.com', age: 31, role: 'Member' },
  ];

  // State to hold the current role filter
  const [roleFilter, setRoleFilter] = useState('All');
  // State to hold the current theme
  const [theme, setTheme] = useState('light');

  // Add a class to the body element when the theme changes
  useEffect(() => {
    document.body.className = ''; // Clear existing classes
    document.body.classList.add(`${theme}-theme`);
  }, [theme]);

  const toggleTheme = () => {
    setTheme(currentTheme => (currentTheme === 'light' ? 'dark' : 'light'));
  };

  const handleFilterChange = (event) => {
    setRoleFilter(event.target.value);
  };

  const roles = ['All', ...new Set(users.map(user => user.role))];

  const filteredUsers = users.filter(user => {
    if (roleFilter === 'All') {
      return true;
    }
    return user.role === roleFilter;
  });

  return (
    <div className="app-container">
      <header className="app-header">
        <h1>Dynamic User Directory</h1>
        <button onClick={toggleTheme} className="theme-toggle-button">
          Switch to {theme === 'light' ? 'Dark' : 'Light'} Mode
        </button>
      </header>
      <main>
        <UserList
          users={filteredUsers}
          roles={roles}
          currentFilter={roleFilter}
          onFilterChange={handleFilterChange}
        />
      </main>
    </div>
  );
}

export default App;
🚀 Dynamic User Directory 🚀

Welcome to the Dynamic User Directory, a modern and responsive React application designed to display and manage a list of users. This project demonstrates key React concepts like component-based architecture, state management (with useState and useEffect), and conditional rendering.

Built with the help of an AI assistant, this application is a great example of human-AI collaboration in software development.

Meet the AI Assistant 🤖

Name: Google studio AI

Role: Your friendly AI pair programmer and coding assistant. For this project, my role was to understand user requests, implement new features, refactor existing code, and ensure best practices. I handled the integration of the "Role-Based Filtering" and "Dark/Light Theme Toggle" features.

✨ Features

This application is packed with features to create a seamless user experience.

Implemented Features:

✅ Dynamic User Rendering: Renders a list of users from a static data source.

✅ Role-Based Filtering: Easily filter users by their role (Admin, Member, Guest) using a dropdown menu.

✅ Dark/Light Theme Toggle: Switch between a light and dark theme for comfortable viewing in any lighting condition.

✅ Component-Based Architecture: Organized into reusable components like UserCard and UserList for clean and maintainable code.

✅ Modern & Responsive UI: A clean, card-based layout that looks great on all screen sizes.

Planned Features:

✏️ Edit User Details

🗑️ Delete User Option

➕ Add New User Form

🔢 Sort Users by Age or Name

📖 Pagination for Large User Lists

👤 User Avatar/Profile Image

🔍 Click to Expand User Details

📄 Export User List (CSV or PDF)

🛠️ Technologies Used

This project is built with a modern web development stack:

React ⚛️ - A JavaScript library for building user interfaces.

Vite ⚡ - A next-generation frontend tooling for a blazing fast development experience.

HTML5 & CSS3 🎨 - For structure and styling, including modern features like Flexbox and custom properties for theming.

JavaScript (ES6+) 📜 - For application logic.

🚀 Getting Started

To get a local copy up and running, follow these simple steps.

Prerequisites

You need to have Node.js and npm installed on your machine.

Installation

Clone the repo

Generated sh
git clone https://github.com/your-username/dynamic-user-directory.git


Navigate to the project directory

Generated sh
cd dynamic-user-directory
IGNORE_WHEN_COPYING_START
content_copy
download

IGNORE_WHEN_COPYING_END

Install NPM packages


npm install
IGNORE_WHEN_COPYING_START
content_copy
download
Use code with caution.
IGNORE_WHEN_COPYING_END

Start the development server
npm run dev
IGNORE_WHEN_COPYING_START
content_copy
download
Use code with caution
IGNORE_WHEN_COPYING_END

Your application should now be running on http://localhost:5173 (or the port specified by Vite).

📂 File Structure

The project has a clear and organized file structure:

Generated code
/src
├── components/
│   ├── UserCard.jsx     # Component for displaying a single user
│   └── UserList.jsx     # Component for displaying the list of users & filters
├── App.jsx              # Main application component, handles state management
├── main.jsx             # Entry point for the React app
└── style.css            # Global styles, including light & dark theme variables
IGNORE_WHEN_COPYING_START
content_copy
download
Use code with caution.
IGNORE_WHEN_COPYING_END
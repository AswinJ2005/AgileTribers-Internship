// src/App.js
// --- COMPLETE OFFLINE SOLUTION ---

import React, { useState, useEffect, useMemo } from 'react';
import {
  Container, Typography, FormControl, InputLabel, Select,
  MenuItem, Box, CircularProgress, Alert, Card, CardContent, colors
} from '@mui/material';
import { WbSunny, Cloud, AcUnit, Whatshot } from '@mui/icons-material';

// --- Data Layer ---

// 1. Predefined list of cities (same as before)
const CITIES = [
  { name: "New York", latitude: 40.71, longitude: -74.01 },
  { name: "London", latitude: 51.51, longitude: -0.13 },
  { name: "Tokyo", latitude: 35.69, longitude: 139.69 },
  { name: "Sydney", latitude: -33.87, longitude: 151.21 },
  { name: "Paris", latitude: 48.85, longitude: 2.35 },
];

// 2. FAKE weather data to simulate an API response
const FAKE_WEATHER_DATA = {
  "New York": { temperature: 28, weathercode: 0, time: "2024-07-10T14:00" }, // Hot and Sunny
  "London":   { temperature: 16, weathercode: 3, time: "2024-07-10T13:00" }, // Mild and Cloudy
  "Tokyo":    { temperature: 31, weathercode: 1, time: "2024-07-10T21:00" }, // Hot and Clear
  "Sydney":   { temperature: 8,  weathercode: 2, time: "2024-07-10T22:00" }, // Cold and Partly Cloudy
  "Paris":    { temperature: 24, weathercode: 3, time: "2024-07-10T15:00" }, // Warm and Overcast
};

// 3. FAKE API fetching logic
// This function perfectly simulates a network request without using the network.
const fetchWeather = async (cityName) => {
  console.log(`--- FAKING API CALL for ${cityName} ---`);

  // Simulate network delay for 500 milliseconds (0.5 seconds)
  await new Promise(resolve => setTimeout(resolve, 500));

  if (FAKE_WEATHER_DATA[cityName]) {
    console.log(`--- Success! Returning fake data for ${cityName} ---`);
    return FAKE_WEATHER_DATA[cityName];
  } else {
    // This will only happen if there's a typo, but it's good practice
    throw new Error("City not found in fake database");
  }
};


// --- UI Component Layer ---

const WeatherDisplayCard = ({ data, cityName }) => {
  const { temperature, weathercode, time } = data;

  const getCardStyle = () => {
    let backgroundColor = colors.grey[500]; // Default grey
    if (temperature > 25) backgroundColor = colors.red[400]; // Hot
    else if (temperature < 10) backgroundColor = colors.blue[400]; // Cold
    return {
      minWidth: 345, backgroundColor, color: '#fff', transition: 'background-color 0.5s ease'
    };
  };
  
  const getWeatherInfo = (code) => {
    if (code === 0) return { description: 'Clear Sky', Icon: Whatshot };
    if (code === 1) return { description: 'Mainly Clear', Icon: WbSunny };
    if (code === 2) return { description: 'Partly Cloudy', Icon: Cloud };
    return { description: 'Overcast', Icon: Cloud };
  };

  const { description, Icon } = getWeatherInfo(weathercode);

  return (
    <Card sx={getCardStyle()}>
      <CardContent>
        <Typography variant="h5" component="div">{cityName}</Typography>
        <Typography variant="caption" display="block" mb={2}>Last updated: {new Date(time).toLocaleString()}</Typography>
        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <Box>
            <Typography variant="h2">{Math.round(temperature)}°C</Typography>
            <Typography variant="h6">{description}</Typography>
          </Box>
          <Icon sx={{ fontSize: 60 }} />
        </Box>
      </CardContent>
    </Card>
  );
};


// --- Main Application ---
function App() {
  const [selectedCityName, setSelectedCityName] = useState(CITIES[0].name);
  const [weatherData, setWeatherData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const getWeatherData = async () => {
      setLoading(true);
      setError(null);
      setWeatherData(null);
      try {
        // We call our fake fetcher, which works exactly the same way as a real one
        const data = await fetchWeather(selectedCityName);
        setWeatherData(data);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };
    getWeatherData();
  }, [selectedCityName]); // The effect re-runs when the city name changes

  return (
    <Container maxWidth="sm">
      <Box sx={{ my: 4, display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
        <Typography variant="h4" component="h1" gutterBottom>Live Weather Dashboard</Typography>
        <FormControl fullWidth sx={{ mb: 4 }}>
          <InputLabel>Select City</InputLabel>
          <Select value={selectedCityName} label="Select City" onChange={(e) => setSelectedCityName(e.target.value)}>
            {CITIES.map((city) => <MenuItem key={city.name} value={city.name}>{city.name}</MenuItem>)}
          </Select>
        </FormControl>
        {loading && <CircularProgress />}
        {error && !loading && <Alert severity="error">{error}</Alert>}
        {weatherData && !loading && !error && <WeatherDisplayCard data={weatherData} cityName={selectedCityName} />}
      </Box>
    </Container>
  );
}
export default App;
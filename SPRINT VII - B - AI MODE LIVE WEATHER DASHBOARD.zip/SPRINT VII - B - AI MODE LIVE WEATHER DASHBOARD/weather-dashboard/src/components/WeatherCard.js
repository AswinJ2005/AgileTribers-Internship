// src/components/WeatherCard.jsx
// Please replace the entire file content with this.

import React from 'react';
import { Card, CardContent, Typography, Box, colors } from '@mui/material';
import { WbSunny, Cloud, Thunderstorm } from '@mui/icons-material';

const getWeatherDescription = (code) => {
  const descriptions = {
    0: 'Clear sky', 1: 'Mainly clear', 2: 'Partly cloudy', 3: 'Overcast',
    45: 'Fog', 48: 'Depositing rime fog', 51: 'Light drizzle', 53: 'Moderate drizzle',
    55: 'Dense drizzle', 61: 'Slight rain', 63: 'Moderate rain', 65: 'Heavy rain',
    80: 'Slight rain showers', 81: 'Moderate rain showers', 82: 'Violent rain showers',
    95: 'Thunderstorm',
  };
  return descriptions[code] || 'Unknown condition';
};

const getWeatherIcon = (code) => {
  if (code === 0) return <WbSunny fontSize="large" sx={{ color: 'white' }} />;
  if (code >= 1 && code <= 48) return <Cloud fontSize="large" sx={{ color: 'white' }} />;
  if (code >= 51) return <Thunderstorm fontSize="large" sx={{ color: 'white' }} />;
  return <Cloud fontSize="large" sx={{ color: 'white' }} />;
};

const WeatherCard = ({ data, cityName }) => {
  const { temperature, weathercode, time } = data;

  const getCardStyle = () => {
    let backgroundColor = colors.grey[500];
    if (temperature > 25) backgroundColor = colors.red[400];
    else if (temperature < 10) backgroundColor = colors.blue[400];
    else if (weathercode > 3) backgroundColor = colors.grey[600];
    return {
      minWidth: 345,
      backgroundColor,
      color: '#fff',
      transition: 'background-color 0.5s ease',
    };
  };

  return (
    <Card sx={getCardStyle()}>
      <CardContent>
        <Typography variant="h5" component="div">
          {cityName}
        </Typography>
        <Typography variant="caption" display="block" mb={2}>
          Last updated: {new Date(time).toLocaleString()}
        </Typography>
        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <Box>
            <Typography variant="h2" component="div">
              {Math.round(temperature)}°C
            </Typography>
            <Typography variant="h6">
              {getWeatherDescription(weathercode)}
            </Typography>
          </Box>
          <Box>
            {getWeatherIcon(weathercode)}
          </Box>
        </Box>
      </CardContent>
    </Card>
  );
};

export default WeatherCard;
// src/api/weather.js
// Please replace the entire file content with this.

export const fetchWeather = async (latitude, longitude) => {
  // Use the secure HTTPS protocol
  const apiUrl = `https://api.open-meteo.com/v1/forecast?latitude=${latitude}&longitude=${longitude}¤t_weather=true`;

  try {
    const response = await fetch(apiUrl);

    if (!response.ok) {
      // Throw an error with the HTTP status to help debugging
      throw new Error(`Network response was not ok: ${response.status} ${response.statusText}`);
    }

    const data = await response.json();
    
    // The API might return an error object in its JSON response
    if (data.error) {
        throw new Error(`API Error: ${data.reason}`);
    }

    if (data && data.current_weather) {
      return data.current_weather;
    } else {
      throw new Error("Invalid data format received from API.");
    }
  } catch (error) {
    // This console.error is vital for seeing the real error in the browser
    console.error("Failed to fetch weather data:", error);
    throw error;
  }
};
document.addEventListener('DOMContentLoaded', () => {
    // DOM Elements
    const taskInput = document.getElementById('task-input');
    const addTaskBtn = document.getElementById('add-task-btn');
    const taskList = document.getElementById('task-list');
    const completedTaskList = document.getElementById('completed-task-list');
    const taskCounter = document.getElementById('task-counter');
    const clearAllBtn = document.getElementById('clear-all-btn');
    const taskManager = document.getElementById('task-manager');
    const priorityInput = document.getElementById('priority-input');
    const dueDateInput = document.getElementById('due-date-input');
    const tagsInput = document.getElementById('tags-input');
    const sortPriorityBtn = document.getElementById('sort-priority-btn');
    const themeToggle = document.getElementById('theme-toggle');
    const voiceInputBtn = document.getElementById('voice-input-btn');
    const taskProgress = document.getElementById('task-progress');
    const progressPercent = document.getElementById('progress-percent');
    const undoToast = document.getElementById('undo-toast');
    const undoBtn = document.getElementById('undo-btn');

    // App State
    let lastDeletedTask = null;
    let undoTimeout = null;

    // --- Sound Effects (Base64 encoded to avoid external files) ---
    const addSound = new Audio("data:audio/mpeg;base64,SUQzBAAAAAAAI1RTU0UAAAAPAAADTGF2ZjU2LjQwLjEwMQAAAAlJbmZvAAAAHwAAAAIAAAGGoN4wDRpFAמ/+GOIE5pAADgABRKM+EAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP/zg/CUAAjAE9i8j6s3h9KVBE6Xb/Vl2B5C1SApaDrUSi4X8iV3Jiy4Cs43o+xZpQy0VJYmOCG3rDPzB91YTUY1h4N+8c9kEyKqqtAOFYGs8MChV3ZPaMaTfY2zjwf5mKCQChIIMmc4iIqVZYpNSOF1L+ifBso1K5GoBs4MztO/4i8/YlR2s7L4iICRtF090zY45/uI4uR1jWnl5SwnWnIYUu324k8k7kPQwQRhMEhBAMKBEMFDwP9GwcFEQcOA5EXQcG5/gQ3i2b4h//zhwxLgAAABpAMTEwLjk4LjEwMAAAAAAAAAAAAAAA//OkjGEAAAAAAAAAAAAcAAAABEluZm8AAAAfAAAAAwAABROg3jAC4/8wAhpAAAAAAAAAQU1EREFwa3NlYwAD/4MkkAABgAAAGoAAAAIAAAMn//8AAAAAAAA/8AAAMP84AgHwAYBkMGE4DDgc8AkAYBAMCAgMAAAAACm//xP/+xMOP8P//8//yP//5g/8YVf8gH/928w3/0M+/8F//9A38nB/n0EAf/9f//7/9v/38//0P/+//44//5h/+Nf9z5n///4D+O2t////sH/y//////lG8v2///gA4H//64e9oIBAABvQIAk/9P/+xAgG3/qT4gH///9pPgAAAA4EABv/+D///xIBAA2///jEgAAYzHhAxMDBm5/9uGIAAA//MMDCAAALADAmAAANf//7//x5D/P///xQDwEA///B//gD/9H/jBQAOAYh+MLv/+n6AP//ADpAP/3zT+8vCMAAAMzAAABAABVBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVX/8AEAAAAAADEwLjk4LjEwMAD/84McQoAACADJAEhGBAggECCAoSgCEEigECgGhBFImCgOhCAGiAKgIBAAIE4mGFAEEGEFGEJAgCBiGggAhgsBhqEAgwBhgAIAgBAAYIAAANVQAf/9YAMwEAQwATwAAIADAzMzM3jAM/////M///jADM///BwBD//hAAD8D+ABHAAAAsEAHwDwAAAAAEABsB4ADSAIAAAD///AAABVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVX/4A");
    const completeSound = new Audio("data:audio/mpeg;base64,SUQzBAAAAAAAI1TUU0UAAAAPAAADTGF2ZjU2LjQwLjEwMQAAAAAAAAAAAEdJbmZvAAAAGgAAAAIAAAGPobgAPSUY9o+iAAAAAAAAAAAAAAAA//OHDEMAAAqgBTRi/m5uMAH2+sAAAAAwEAwQAc1lKAbpBVxN8uY/pNE8qGQQo0hNnDH//AAAAuRzM/0BAQD+Pv6//zM0ABAn+oHh+k/+3g0ADgB/+mAAAA/+gB/+AIEBgIAAgQCBQQEAAACABAYGAQCA//OHLEMAAAwghpADyADGFBGMMWQA6oABg5GAIYShpKOAAAAAQABCAIAAFAAGADyABkADRg5AAAAABVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVX/AACABAAAAFBVTEFWRgAAA//OHLAMAQAAAAGABERAAnAPy0MgtIAAAABmABGAAnAfyqBhtJAD/xgABwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACYAAAKAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD//5w4YgAAIgAgQWAAAAAQAwAAgJABQCQgKAgAUEAgQEAv//ziwxDAMyASoAqQCATgYBGggEDkYNBoKBCUOCggCDYEBAoEBEICAgJjAIgAAJAAAAgAAAAFB/oD/ogAADEADQkAGB/+gACAAAAAAAAAAAAAAAAAAAAAVYAP/wAAAAAAAAKqoAqP//////FVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVX/AAABAAAGUAAAA//OHFGMACgoC0/95uS2/1+4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA//MCHEcAkAAAASDBAWFwwIEBAaDAYEDgkECAQMDAkEAgMDA8PAhYEBgYEAAAQEBAUADRQBw///3//+3f79/v//d////1/AD//+gYCBf8AAAAAAAAAAAAAYCBf//gAEAwBgB+AQAAB/8EAAAAAAAAAABAABgIAAPQAAAAAzMxCQAEAAAAmZmAQAAD//wAACAQBgEAAAAD4H/+AAAAsBQAYGA/wAAPAwD//+BgAAAAEBgP/AFAAAB8DAf//AgAAAQEAgBACAADfAIAAADMAADNmMmYAAAAMzAAAB//mZmZmP//AADP+f///9////2P//v/X//2AAAAAAPQAAFQAAC/Vf8v////oP//w////u//+//b7/////////8N//r/////n///////y//+/85/v3r////6+fn+vn/f/////////6AFVVAEH+jAEMwAMArADhQgAqAMAMxMAQRUAAAAAAAAAAAAAAAAABVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVf/AAgA==");

    // --- Event Listeners ---
    addTaskBtn.addEventListener('click', addTaskFromInput);
    taskInput.addEventListener('keydown', e => e.key === 'Enter' && addTaskFromInput());
    taskManager.addEventListener('click', handleTaskAction);
    clearAllBtn.addEventListener('click', clearAllTasks);
    sortPriorityBtn.addEventListener('click', sortTasksByPriority);
    themeToggle.addEventListener('change', toggleTheme);
    voiceInputBtn.addEventListener('click', startVoiceRecognition);
    undoBtn.addEventListener('click', () => {
        if(lastDeletedTask) {
            recreateTask(lastDeletedTask.data, lastDeletedTask.originalList);
            lastDeletedTask = null;
            hideUndoToast();
            updateAll();
        }
    });

    // --- Initialization ---
    loadTheme();
    loadTasks();
    setInterval(checkOverdueTasks, 60000); // Check for overdue tasks every minute

    // --- Core Functions ---
    function addTaskFromInput() {
        const taskText = taskInput.value.trim();
        if (taskText === '') {
            alert('Please enter a task.');
            return;
        }

        const taskData = {
            id: Date.now().toString(),
            text: taskText,
            priority: priorityInput.value,
            dueDate: dueDateInput.value,
            tags: tagsInput.value.split(',').map(t => t.trim()).filter(t => t),
            isCompleted: false
        };

        createTaskElement(taskData, taskList);
        addSound.play();

        taskInput.value = '';
        tagsInput.value = '';
        dueDateInput.value = '';
        priorityInput.value = 'medium';
        taskInput.focus();

        updateAll();
    }
    
    function createTaskElement(taskData, targetList) {
        const li = document.createElement('li');
        li.className = 'task-item';
        li.dataset.id = taskData.id;
        li.dataset.priority = taskData.priority;
        li.draggable = !taskData.isCompleted;

        const tagsHTML = taskData.tags.map(tag => `<span class="tag">${tag}</span>`).join('');
        const dueDateHTML = taskData.dueDate ? `<span class="due-date">Due: ${taskData.dueDate}</span>` : '';
        
        li.innerHTML = `
            <input type="checkbox" class="complete-checkbox" title="Mark as complete" ${taskData.isCompleted ? 'checked' : ''}>
            <div class="task-content">
                <span class="task-text">${taskData.text}</span>
                <div class="task-meta">
                    <span class="priority-tag ${taskData.priority}">${taskData.priority}</span>
                    ${dueDateHTML}
                    <div class="tags-container">${tagsHTML}</div>
                </div>
            </div>
            <div class="task-actions">
                <button class="edit-btn" title="Edit Task" ${taskData.isCompleted ? 'disabled' : ''}>📝</button>
                <button class="delete-btn" title="Delete Task">🗑️</button>
            </div>
        `;
        
        targetList.prepend(li);
        checkOverdueStatus(li, taskData.dueDate); // Initial check
        return li;
    }

    function handleTaskAction(e) {
        const target = e.target;
        const taskItem = target.closest('.task-item');
        if (!taskItem) return;

        const taskId = taskItem.dataset.id;

        if (target.classList.contains('complete-checkbox')) {
            toggleTaskCompletion(taskItem, taskId);
        } else if (target.classList.contains('delete-btn')) {
            deleteTask(taskItem, taskId);
        } else if (target.classList.contains('edit-btn')) {
            handleEditTask(target, taskItem, taskId);
        }
    }
    
    function updateAll() {
        updateTaskCounter();
        updateProgressBar();
        updateTagFilters();
        saveTasks();
        checkConfetti();
    }
    
    // --- Feature Implementations ---

    // Prioritization & Sorting
    function sortTasksByPriority() {
        const tasks = Array.from(taskList.children);
        const priorityOrder = { high: 0, medium: 1, low: 2 };

        tasks.sort((a, b) => {
            const priorityA = priorityOrder[a.dataset.priority];
            const priorityB = priorityOrder[b.dataset.priority];
            return priorityA - priorityB;
        });

        tasks.forEach(task => taskList.appendChild(task));
        saveTasks();
    }

    // Due Dates & Overdue Status
    function checkOverdueTasks() {
        document.querySelectorAll('#task-list .task-item').forEach(taskItem => {
            const taskData = getTaskDataFromElement(taskItem);
            checkOverdueStatus(taskItem, taskData.dueDate);
        });
    }

    function checkOverdueStatus(taskItem, dueDateStr) {
        if (!dueDateStr) return;
        const now = new Date();
        const dueDate = new Date(dueDateStr);
        // Set time to end of day for comparison
        now.setHours(0,0,0,0);
        dueDate.setHours(23,59,59,999);
        if (dueDate < now) {
            taskItem.classList.add('overdue');
        } else {
            taskItem.classList.remove('overdue');
        }
    }

    // Task Completion
    function toggleTaskCompletion(taskItem) {
        const checkbox = taskItem.querySelector('.complete-checkbox');
        const editBtn = taskItem.querySelector('.edit-btn');
        taskItem.classList.remove('overdue');
        
        if (checkbox.checked) {
            completeSound.play();
            completedTaskList.prepend(taskItem);
            editBtn.disabled = true;
            taskItem.draggable = false;
        } else {
            taskList.appendChild(taskItem);
            editBtn.disabled = false;
            taskItem.draggable = true;
            checkOverdueStatus(taskItem, getTaskDataFromElement(taskItem).dueDate);
        }
        updateAll();
    }
    
    // Edit Task
    function handleEditTask(editButton, taskItem) {
        const taskTextSpan = taskItem.querySelector('.task-text');
        
        if (editButton.textContent.includes('📝')) {
            const currentText = taskTextSpan.textContent;
            taskTextSpan.innerHTML = `<input type="text" class="edit-input" value="${currentText}">`;
            const editInput = taskTextSpan.querySelector('.edit-input');
            editInput.focus();
            editInput.addEventListener('keydown', (e) => {
                if(e.key === 'Enter') {
                     saveEdit(editButton, taskItem, editInput.value);
                } else if(e.key === 'Escape') {
                     saveEdit(editButton, taskItem, currentText);
                }
            });
            editButton.innerHTML = '💾';
        } else {
           const editInput = taskItem.querySelector('.edit-input');
           saveEdit(editButton, taskItem, editInput.value);
        }
    }
    
    function saveEdit(editButton, taskItem, newText) {
        const taskTextSpan = taskItem.querySelector('.task-text');
         if (newText.trim()) {
                taskTextSpan.textContent = newText;
        }
        editButton.innerHTML = '📝';
        updateAll();
    }

    // Delete Task & Undo
    function deleteTask(taskItem) {
        // Store data for undo
        lastDeletedTask = {
            data: getTaskDataFromElement(taskItem),
            originalList: taskItem.closest('ul')
        };

        // Fade out animation
        taskItem.classList.add('fade-out');
        taskItem.addEventListener('animationend', () => {
            taskItem.remove();
            if (lastDeletedTask && lastDeletedTask.data.id === taskItem.dataset.id) {
                 clearTimeout(undoTimeout);
                 undoTimeout = setTimeout(() => {
                    lastDeletedTask = null;
                    hideUndoToast();
                 }, 5000); // 5 seconds to undo
            }
            updateAll();
        });

        showUndoToast();
    }
    
    function showUndoToast() {
        undoToast.classList.add('show');
    }
    
    function hideUndoToast() {
        undoToast.classList.remove('show');
        clearTimeout(undoTimeout);
    }

    // Categories and Filtering
    function updateTagFilters() {
        const allTasks = [...document.querySelectorAll('.task-item')];
        const allTags = new Set(allTasks.flatMap(task => getTaskDataFromElement(task).tags));
        
        const filterContainer = document.getElementById('tag-filters');
        filterContainer.innerHTML = '<button class="active">All</button>';

        allTags.forEach(tag => {
            const btn = document.createElement('button');
            btn.textContent = tag;
            filterContainer.appendChild(btn);
        });
        
        // Add event listeners to new buttons
        filterContainer.querySelectorAll('button').forEach(btn => {
            btn.addEventListener('click', () => {
                filterByTag(btn.textContent);
                filterContainer.querySelector('.active').classList.remove('active');
                btn.classList.add('active');
            });
        });
    }

    function filterByTag(selectedTag) {
        const allTasks = [...taskList.children, ...completedTaskList.children];
        allTasks.forEach(task => {
            if(selectedTag === 'All' || getTaskDataFromElement(task).tags.includes(selectedTag)) {
                task.style.display = 'flex';
            } else {
                task.style.display = 'none';
            }
        });
    }

    // Drag and Drop
    let draggedItem = null;
    taskManager.addEventListener('dragstart', e => {
        if(e.target.classList.contains('task-item')){
            draggedItem = e.target;
            setTimeout(() => e.target.classList.add('dragging'), 0);
        }
    });

    taskManager.addEventListener('dragend', e => {
         if(e.target.classList.contains('task-item')){
            e.target.classList.remove('dragging');
            draggedItem = null;
            saveTasks();
        }
    });
    
    taskManager.addEventListener('dragover', e => {
        if(e.target.closest('.task-area')) {
            e.preventDefault();
            const afterElement = getDragAfterElement(e.target.closest('.task-area'), e.clientY);
            const container = e.target.closest('.task-area');
            if(afterElement == null) {
                container.appendChild(draggedItem);
            } else {
                container.insertBefore(draggedItem, afterElement);
            }
        }
    });

    function getDragAfterElement(container, y) {
        const draggableElements = [...container.querySelectorAll('.task-item:not(.dragging)')];

        return draggableElements.reduce((closest, child) => {
            const box = child.getBoundingClientRect();
            const offset = y - box.top - box.height / 2;
            if(offset < 0 && offset > closest.offset) {
                return { offset: offset, element: child };
            } else {
                return closest;
            }
        }, { offset: Number.NEGATIVE_INFINITY }).element;
    }

    // Local Storage
    function saveTasks() {
        const pendingTasks = Array.from(taskList.children).map(getTaskDataFromElement);
        const completedTasks = Array.from(completedTaskList.children).map(getTaskDataFromElement);
        localStorage.setItem('tasks', JSON.stringify({ pending: pendingTasks, completed: completedTasks }));
    }

    function loadTasks() {
        const data = JSON.parse(localStorage.getItem('tasks'));
        if(data) {
            data.pending.forEach(task => recreateTask(task, taskList));
            data.completed.forEach(task => recreateTask(task, completedTaskList));
        }
        updateAll();
        checkOverdueTasks();
    }
    
    function recreateTask(taskData, targetList){
       taskData.isCompleted = targetList === completedTaskList;
       createTaskElement(taskData, targetList);
    }
    
    function getTaskDataFromElement(taskItem) {
        const isCompleted = taskItem.closest('ul').id === 'completed-task-list';
        return {
            id: taskItem.dataset.id,
            text: taskItem.querySelector('.task-text').textContent,
            priority: taskItem.dataset.priority,
            dueDate: taskItem.querySelector('.due-date')?.textContent.replace('Due: ', ''),
            tags: [...taskItem.querySelectorAll('.tag')].map(t => t.textContent),
            isCompleted: isCompleted,
        };
    }
    
    // Theme Toggling
    function toggleTheme() {
        document.body.classList.toggle('dark-mode');
        localStorage.setItem('theme', document.body.classList.contains('dark-mode') ? 'dark' : 'light');
    }
    
    function loadTheme() {
        const theme = localStorage.getItem('theme');
        if(theme === 'dark') {
            document.body.classList.add('dark-mode');
            themeToggle.checked = true;
        }
    }
    
    // Voice Input (Web Speech API)
    function startVoiceRecognition() {
        window.SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        if (!window.SpeechRecognition) {
            alert("Sorry, your browser doesn't support voice recognition.");
            return;
        }

        const recognition = new SpeechRecognition();
        recognition.interimResults = false;
        recognition.lang = 'en-US';

        recognition.addEventListener('result', e => {
            const transcript = Array.from(e.results)
                .map(result => result[0])
                .map(result => result.transcript)
                .join('');
            taskInput.value = transcript;
        });
        
        recognition.addEventListener('end', () => {
             if (taskInput.value.trim() !== '') {
                addTaskFromInput();
             }
        });

        recognition.start();
    }

    // Misc UI Updates
    function updateTaskCounter() {
        const pendingCount = taskList.children.length;
        taskCounter.textContent = `You have ${pendingCount} pending task${pendingCount !== 1 ? 's' : ''}.`;
    }

    function updateProgressBar() {
        const pendingCount = taskList.children.length;
        const completedCount = completedTaskList.children.length;
        const totalCount = pendingCount + completedCount;
        const percent = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;
        
        taskProgress.value = percent;
        progressPercent.textContent = `${percent}%`;
    }

    function checkConfetti() {
        if (taskList.children.length === 0 && completedTaskList.children.length > 0) {
            confetti({
                particleCount: 150,
                spread: 90,
                origin: { y: 0.6 }
            });
        }
    }

    function clearAllTasks() {
        if (confirm('Are you sure you want to clear ALL tasks? This cannot be undone.')) {
            taskList.innerHTML = '';
            completedTaskList.innerHTML = '';
            updateAll();
        }
    }
});
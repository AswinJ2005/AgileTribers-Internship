To-Do List Pro

✨ Key Features

✅ Priority Levels: Assign High, Medium, or Low priority to tasks with color-coded tags.

🗓️ Due Dates: Set due dates for tasks, and overdue items are automatically highlighted.

📁 Task Tags: Categorize tasks with custom tags (e.g., work, personal) and filter your list.

🌓 Dark & Light Mode: Switch between themes for comfortable viewing day or night.

💾 Persistent Storage: All tasks and settings are automatically saved in your browser.

📌 Drag & Drop: Easily reorder your pending tasks to match your workflow.

↩️ Undo Delete: Accidentally deleted a task? You have 5 seconds to undo it.

🎤 Voice Input: Add tasks hands-free using your microphone.

📊 Progress Bar: Visually track your completion percentage.

🎉 Confetti Celebration: Enjoy a fun confetti effect when you complete all your tasks!

📱 Fully Responsive: Looks and works great on desktops, tablets, and mobile phones.

🚀 How to Run

No installation is needed! Just follow these simple steps:

Make sure all three files (index.html, style.css, script.js) are in the same folder.

Double-click on the index.html file.

The application will open in your default web browser.

That's it! You're ready to start organizing your life.

🛠️ Technologies Used

HTML5: For the core structure of the application.

CSS3: For all styling, including dark mode, animations, and responsive design.

JavaScript (ES6+): For all application logic and interactivity.

document.addEventListener('DOMContentLoaded', () => {

    // --- DOM ELEMENT SELECTIONS ---
    const timeEl = document.getElementById('time');
    const dateEl = document.getElementById('date');
    const greetingEl = document.getElementById('greeting');
    const formatToggle = document.getElementById('format-toggle');
    const tickToggle = document.getElementById('tick-toggle');
    const timezoneSelect = document.getElementById('timezone-select');
    const themeToggle = document.getElementById('theme-checkbox');
    const fullscreenBtn = document.getElementById('fullscreen-btn');
    const alarmTimeInput = document.getElementById('alarm-time');
    const addAlarmBtn = document.getElementById('add-alarm-btn');
    const alarmList = document.getElementById('alarm-list');
    const tickSound = document.getElementById('tick-sound');
    const alarmSound = document.getElementById('alarm-sound');

    // --- STATE VARIABLES ---
    let is24HourFormat = false;
    let playTickingSound = false;
    let selectedTimeZone = Intl.DateTimeFormat().resolvedOptions().timeZone;
    let alarms = [];
    let isAudioInitialized = false;

    // --- INITIALIZATION ---
    populateTimezones();
    updateClock();
    setInterval(updateClock, 1000);
    // Universal audio unlocker
    document.body.addEventListener('click', initAudio, { once: true });


    // --- CORE & HELPER FUNCTIONS ---

    function updateClock() {
        const now = new Date(new Date().toLocaleString('en-US', { timeZone: selectedTimeZone }));
        timeEl.textContent = formatTime(now);
        dateEl.textContent = formatDate(now);
        greetingEl.textContent = getGreeting(now);

        if (playTickingSound) {
            tickSound.play().catch(() => {});
        }
        checkAlarms(now);
    }

    function initAudio() {
        if (isAudioInitialized) return;
        Promise.all([alarmSound.play(), tickSound.play()]).then(() => {
            [alarmSound, tickSound].forEach(sound => {
                sound.pause();
                sound.currentTime = 0;
            });
            isAudioInitialized = true;
            console.log("Audio unlocked.");
        }).catch(() => {});
    }
    
    function populateTimezones() {
        const timezones = Intl.supportedValuesOf('timeZone');
        timezones.forEach(tz => {
            const option = document.createElement('option');
            option.value = tz;
            option.textContent = tz.replace(/_/g, ' ');
            if (tz === selectedTimeZone) option.selected = true;
            timezoneSelect.appendChild(option);
        });
    }

    // --- ALARM LOGIC (Unchanged) ---
    function addAlarm(){initAudio();const e=alarmTimeInput.value;if(e&&!alarms.includes(e))alarms.push(e),renderAlarms(),alarmTimeInput.value="";else if(e)alert("Alarm is already set for this time.");else alert("Please select a valid time.")}
    function renderAlarms(){alarmList.innerHTML="";alarms.sort().forEach(e=>{const t=document.createElement("li"),a=e.split(":"),r=is24HourFormat?e:`${(parseInt(a[0])%12||12).toString().padStart(2,"0")}:${a[1]} ${parseInt(a[0])>=12?"PM":"AM"}`;t.textContent=r;const n=document.createElement("button");n.textContent="✖",n.className="remove-alarm-btn",n.title="Remove Alarm",n.dataset.alarm=e,t.appendChild(n),alarmList.appendChild(t)})}
    function removeAlarm(e){alarms=alarms.filter(t=>t!==e);renderAlarms()}
    function checkAlarms(e){if(0===e.getSeconds()){const t=`${String(e.getHours()).padStart(2,"0")}:${String(e.getMinutes()).padStart(2,"0")}`;alarms.includes(t)&&triggerAlarm(t)}}
    function triggerAlarm(e){if(document.body.classList.contains("alarm-ringing"))return;alarmSound.play(),document.body.classList.add("alarm-ringing"),alert(`ALARM! It's time for your ${e} alarm.`),alarmSound.pause(),alarmSound.currentTime=0,document.body.classList.remove("alarm-ringing"),removeAlarm(e)}
    
    // --- FORMATTING FUNCTIONS (Unchanged) ---
    function formatTime(e){let t=e.getHours();const a=String(e.getMinutes()).padStart(2,"0"),r=String(e.getSeconds()).padStart(2,"0");if(is24HourFormat)return`${String(t).padStart(2,"0")}:${a}:${r}`;{const n=t>=12?"PM":"AM";return t=t%12||12,`${String(t).padStart(2,"0")}:${a}:${r} ${n}`}}
    function formatDate(e){return e.toLocaleDateString("en-US",{weekday:"long",year:"numeric",month:"long",day:"numeric"})}
    function getGreeting(e){const t=e.getHours();return t>=5&&t<12?"Good Morning!":t>=12&&t<18?"Good Afternoon!":"Good Evening!"}
    
    // --- EVENT LISTENERS (Unchanged) ---
    formatToggle.addEventListener("change",()=>{is24HourFormat=formatToggle.checked,updateClock(),renderAlarms()});
    tickToggle.addEventListener("change",()=>{playTickingSound=tickToggle.checked});
    timezoneSelect.addEventListener("change",e=>{selectedTimeZone=e.target.value;updateClock()});
    themeToggle.addEventListener("change",()=>document.body.classList.toggle("light-mode",themeToggle.checked));
    fullscreenBtn.addEventListener("click",()=>{document.fullscreenElement?document.exitFullscreen():document.documentElement.requestFullscreen().catch(()=>{})});
    addAlarmBtn.addEventListener("click",addAlarm);
    alarmList.addEventListener("click",e=>{e.target.classList.contains("remove-alarm-btn")&&removeAlarm(e.target.dataset.alarm)});
});
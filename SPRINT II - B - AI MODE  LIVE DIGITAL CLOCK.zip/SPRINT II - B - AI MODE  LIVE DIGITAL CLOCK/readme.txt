Dynamic Time-Keeping Web Application using AI Mode

Features

Live Time & Date: Displays the current time (HH:MM:SS) and date, updating every second.

12/24-Hour Toggle: Easily switch between 12-hour (AM/PM) and 24-hour time formats.

Time Zone Selector: Select and view the current time from any time zone around the world.

Custom Greeting: Shows a friendly message ("Good Morning," "Good Afternoon," or "Good Evening") based on the local time.

Multiple Alarms: Set multiple alarms that trigger an audible alert at the specified times.

Dark/Light Mode: Toggle between a sleek dark theme and a clean light theme.

Ticking Sound: Optional ticking sound for every second that passes.

Live Weather Widget: Displays live weather using a third-party <iframe> widget.

Modern & Responsive UI: Features a "glassmorphism" design that looks great on desktop and mobile.

Full-Screen Mode: View the clock in a distraction-free, full-screen view.

File Structure

The project uses the following file structure. Make sure your local copy is organized this way for all assets to load correctly.

Generated code
enhanced-digital-clock/
├── index.html
├── style.css
├── script.js
├── README.md
└── sounds/
    ├── tick.mp3
    └── alarm.mp3

Tech Stack

HTML5: For the core structure and content.

CSS3: For styling, animations, responsiveness, and theming.

JavaScript (ES6+): For all client-side logic, including time updates, alarm handling, and DOM manipulation.

How to Run

Download the project files (index.html, style.css, script.js).

Open index.html in any web browser.

AI Used

This project was developed with the assistance of an AI model (Google's Gemini) for code generation, feature implementation, debugging complex issues (such as CORS and local file restrictions), and creating documentation. The AI played a significant role in providing alternative solutions and troubleshooting environmental blocking issues.
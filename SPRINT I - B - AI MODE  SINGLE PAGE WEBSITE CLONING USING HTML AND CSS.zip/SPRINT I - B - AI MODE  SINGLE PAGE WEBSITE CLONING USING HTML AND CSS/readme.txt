AWS Educate Page Clone using 

AI Tool Used: Gemini 2.5 Pro Preview by Google Studio AI

This project is a static front-end clone of the AWS Educate landing page, built using plain HTML and CSS. The goal was to replicate the visual design and layout of the page, including its modern, animated gradient background.

Features

Static Clone: A faithful visual representation of the AWS Educate page structure.

Animated Background: A smooth, color-shifting background gradient created entirely with CSS animations to mimic the effect on the live website.

Pure CSS & HTML: Built without any JavaScript frameworks or libraries for simplicity.

Structured Layout: Clean and organized HTML structure with a corresponding stylesheet.

How to Use

To view the project, simply follow these steps:

Clone or download the repository to your local machine.

Make sure you have the index.html, style.css, and the images folder in the same directory.

Open the index.html file in any modern web browser (like Chrome, Firefox, or Edge).

Files

index.html: Contains the main HTML structure of the page.

style.css: Contains all the styling, including the layout, fonts, colors, and the background animation.

/images: A folder containing all the icons and logos used on the page. (You will need to add the image files referenced in the HTML for them to appear).

Preview

The final result is a clean webpage with a header, navigation bars, and a hero section. The background slowly and subtly shifts between soft shades of purple, blue, and white, creating a calm and professional aesthetic.
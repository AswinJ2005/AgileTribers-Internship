// File: src/BookCard.jsx

import React from 'react';
import { Card, CardContent, CardMedia, Typography, Grid } from '@mui/material';

const BookCard = ({ book }) => {
  const coverImageUrl = book.cover_i 
    ? `https://covers.openlibrary.org/b/id/${book.cover_i}-M.jpg` 
    : 'https://via.placeholder.com/128x192.png?text=No+Cover';
    
  return (
    <Grid item xs={12} sm={6} md={4} lg={3}>
      <Card 
        sx={{ 
          height: '100%', 
          display: 'flex', 
          flexDirection: 'column',
          transition: 'transform 0.2s ease-in-out',
          '&:hover': {
            transform: 'scale(1.03)',
            boxShadow: 6,
          }
        }}
      >
        <CardMedia
          component="img"
          sx={{ 
            aspectRatio: '3 / 4',
            objectFit: 'cover'
          }}
          image={coverImageUrl}
          alt={`Cover for ${book.title}`}
        />
        <CardContent sx={{ flexGrow: 1 }}>
          <Typography gutterBottom variant="h6" component="h2" noWrap>
            {book.title}
          </Typography>
          <Typography variant="body2" color="text.secondary">
            {book.author_name ? book.author_name.join(', ') : 'Unknown Author'}
          </Typography>
        </CardContent>
      </Card>
    </Grid>
  );
};

export default BookCard;
// src/mockApi.js

import { mockBooks } from './mockData';

const PAGE_SIZE = 8; // Number of books to return per "page"

/**
 * Simulates fetching books from an API with search and pagination.
 * @param {string} query - The search term for the books.
 * @param {number} page - The page number of the results to fetch.
 * @returns {Promise<object>} A promise that resolves to an API-like response object.
 */
export const fetchMockBooks = (query, page) => {
  console.log(`Fetching mock data for query: "${query}", page: ${page}`);
  
  // Return a Promise to mimic a real asynchronous API call
  return new Promise((resolve) => {
    setTimeout(() => {
      // 1. Handle empty query
      if (!query) {
        resolve({ docs: [], numFound: 0 });
        return;
      }
      
      // 2. Filter the data based on the search query (case-insensitive)
      const filteredBooks = mockBooks.filter(book => 
        book.title.toLowerCase().includes(query.toLowerCase())
      );
      
      // 3. Paginate the filtered results
      const startIndex = (page - 1) * PAGE_SIZE;
      const paginatedBooks = filteredBooks.slice(startIndex, startIndex + PAGE_SIZE);

      // 4. Resolve the promise with a structure identical to the real API
      resolve({
        docs: paginatedBooks,        // The books for the current page
        numFound: filteredBooks.length // The total number of books found for the query
      });
      
    }, 500); // Simulate a 500ms network delay
  });
};
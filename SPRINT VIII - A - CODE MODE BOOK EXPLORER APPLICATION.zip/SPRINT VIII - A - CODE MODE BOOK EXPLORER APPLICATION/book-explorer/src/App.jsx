// File: src/App.jsx

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { 
  Container, 
  TextField, 
  Grid, 
  Typography, 
  CircularProgress, 
  Box, 
  AppBar, 
  Toolbar, 
  Card, 
  CardContent, 
  CardMedia 
} from '@mui/material';
import { fetchMockBooks } from './mockApi';

// ======================================================================
// BookCard COMPONENT IS NOW DEFINED INSIDE APP.JSX
// This removes the need for a separate file and import.
// ======================================================================
const BookCard = ({ book }) => {
  const coverImageUrl = book.cover_i 
    ? `https://covers.openlibrary.org/b/id/${book.cover_i}-M.jpg` 
    : 'https://via.placeholder.com/128x192.png?text=No+Cover';
    
  return (
    <Grid item xs={12} sm={6} md={4} lg={3}>
      <Card sx={{ height: '100%', display: 'flex', flexDirection: 'column', transition: 'transform 0.2s ease-in-out', '&:hover': { transform: 'scale(1.03)', boxShadow: 6, } }}>
        <CardMedia component="img" sx={{ aspectRatio: '3 / 4', objectFit: 'cover' }} image={coverImageUrl} alt={`Cover for ${book.title}`} />
        <CardContent sx={{ flexGrow: 1 }}>
          <Typography gutterBottom variant="h6" component="h2" noWrap>{book.title}</Typography>
          <Typography variant="body2" color="text.secondary">{book.author_name ? book.author_name.join(', ') : 'Unknown Author'}</Typography>
        </CardContent>
      </Card>
    </Grid>
  );
};

// ======================================================================
// The Main App Component
// ======================================================================
function App() {
  const [searchTerm, setSearchTerm] = useState('the');
  const [books, setBooks] = useState([]);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(false);
  const [hasMore, setHasMore] = useState(true);

  const debounceTimeoutRef = useRef(null);
  const observer = useRef();

  const lastBookElementRef = useCallback(node => {
    if (loading) return;
    if (observer.current) observer.current.disconnect();
    observer.current = new IntersectionObserver(entries => {
      if (entries[0].isIntersecting && hasMore) {
        setPage(prevPage => prevPage + 1);
      }
    });
    if (node) observer.current.observe(node);
  }, [loading, hasMore]);

  useEffect(() => {
    setLoading(true);
    fetchMockBooks(searchTerm, page).then(data => {
      setBooks(prevBooks => (page === 1 ? data.docs : [...prevBooks, ...data.docs]));
      setHasMore(data.numFound > (page * 8));
      setLoading(false);
    });
  }, [searchTerm, page]);

  const handleSearch = (event) => {
    const newSearchTerm = event.target.value;
    if (debounceTimeoutRef.current) clearTimeout(debounceTimeoutRef.current);
    debounceTimeoutRef.current = setTimeout(() => {
      setSearchTerm(newSearchTerm);
      setPage(1);
      setBooks([]);
    }, 500);
  };

  return (
    <>
      <AppBar position="sticky">
        <Toolbar>
          <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
            Book Explorer Application
          </Typography>
        </Toolbar>
      </AppBar>
      <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
        <Box sx={{ mb: 4 }}>
          <TextField fullWidth label="Search for books by title" variant="outlined" defaultValue="the" onChange={handleSearch} />
        </Box>
        <Grid container spacing={4}>
          {books.map((book, index) => {
            if (books.length === index + 1) {
              return <BookCard book={book} key={`${book.key}-${index}`} ref={lastBookElementRef} />;
            } else {
              return <BookCard book={book} key={`${book.key}-${index}`} />;
            }
          })}
        </Grid>
        {loading && <Box sx={{ display: 'flex', justifyContent: 'center', mt: 4 }}><CircularProgress /></Box>}
      </Container>
    </>
  );
}

export default App;
User Management Table - Job Simulation Project

This project is a front-end development task to create a dynamic user management table. It fetches user data from the JSONPlaceholder API and renders it using pure JavaScript DOM manipulation. Users can be edited inline or deleted directly from the UI.

Features

Fetch Data: Retrieves user data from a remote JSON API.

Dynamic Table: Builds the HTML table dynamically using JavaScript.

Inline Editing: Click "Edit" to turn a row's cells into input fields. Click "Save" to commit the changes.

Delete Rows: Click "Delete" to remove a user's row from the table.

Styled UI: Clean, modern styling with alternating row colors, a hover effect, and distinct action buttons.

Responsive: The table is horizontally scrollable on small screens to prevent layout breaking.

Technology Stack

HTML: For the basic structure and container.

CSS: For all styling, including layout, table design, and buttons.

JavaScript (ES6+): For fetching data (Fetch API, async/await), manipulating the DOM, and handling events.

How to Run

No special installation is required. Just follow these steps:

Make sure you have all three files (index.html, style.css, script.js) in the same folder.

Open the index.html file in your web browser (e.g., Google Chrome, Firefox, Safari).

An internet connection is required to fetch the user data from the API.

File Structure

index.html: The main HTML file containing the structure for the page.

style.css: Contains all CSS styling for the table, buttons, and layout.

script.js: Handles all the logic, including the API call, DOM creation, and event listeners for Edit/Delete functionality.
document.addEventListener('DOMContentLoaded', () => {
    const API_URL = 'https://jsonplaceholder.typicode.com/users';
    const tableBody = document.getElementById('table-body');

    async function fetchUsers() {
        try {
            const response = await fetch(API_URL);
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            const users = await response.json();
            users.forEach(user => {
                const row = createUserRow(user);
                tableBody.appendChild(row);
            });
        } catch (error) {
            console.error("Could not fetch users:", error);
            tableBody.innerHTML = '<tr><td colspan="5" style="text-align:center; color:red;">Failed to load user data.</td></tr>';
        }
    }

    function createUserRow(user) {
        const row = document.createElement('tr');
        row.dataset.userId = user.id;

        row.innerHTML = `
            <td data-field="name">${user.name}</td>
            <td data-field="username">${user.username}</td>
            <td data-field="email">${user.email}</td>
            <td data-field="phone">${user.phone}</td>
            <td class="action-cell">
                <button class="btn btn-edit">Edit</button>
                <button class="btn btn-delete">Delete</button>
            </td>
        `;

        const editButton = row.querySelector('.btn-edit');
        const deleteButton = row.querySelector('.btn-delete');

        editButton.addEventListener('click', handleEditSave);
        deleteButton.addEventListener('click', () => {
            row.remove();
        });

        return row;
    }

    function handleEditSave(event) {
        const button = event.target;
        const row = button.closest('tr');
        const isEditing = button.textContent === 'Save';

        const editableCells = row.querySelectorAll('td[data-field]');

        if (isEditing) {
            editableCells.forEach(cell => {
                const input = cell.querySelector('input');
                cell.textContent = input.value;
            });

            button.textContent = 'Edit';
            button.classList.replace('btn-save', 'btn-edit');
        } else {
            editableCells.forEach(cell => {
                const currentValue = cell.textContent;
                cell.innerHTML = `<input type="text" value="${currentValue}">`;
            });

            button.textContent = 'Save';
            button.classList.replace('btn-edit', 'btn-save');
        }
    }

    fetchUsers();
});
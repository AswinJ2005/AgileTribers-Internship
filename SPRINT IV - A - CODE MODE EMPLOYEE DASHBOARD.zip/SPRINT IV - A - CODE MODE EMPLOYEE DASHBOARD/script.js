document.addEventListener('DOMContentLoaded', () => {

    // 1. Functionality: Create employee data
    const employees = [
        { id: 1, name: 'Alice Johnson', age: 32, department: 'Engineering', role: 'Software Engineer', salary: 95000 },
        { id: 2, name: 'Bob Smith', age: 28, department: 'Marketing', role: 'Marketing Specialist', salary: 65000 },
        { id: 3, name: 'Charlie Brown', age: 45, department: 'HR', role: 'HR Manager', salary: 105000 },
        { id: 4, name: 'Diana Prince', age: 38, department: 'Engineering', role: 'Project Manager', salary: 115000 },
        { id: 5, name: 'Ethan Hunt', age: 30, department: 'Sales', role: 'Sales Representative', salary: 75000 },
        { id: 6, name: 'Fiona Glenanne', age: 35, department: 'Marketing', role: 'Content Strategist', salary: 72000 },
        { id: 7, name: 'George Costanza', age: 41, department: 'Sales', role: 'Sales Manager', salary: 110000 },
        { id: 8, name: 'Hannah Montana', age: 26, department: 'Engineering', role: 'UI/UX Designer', salary: 85000 },
    ];

    // Get references to DOM elements
    const employeeTableBody = document.getElementById('employeeTableBody');
    const departmentFilter = document.getElementById('departmentFilter');
    const searchInput = document.getElementById('searchInput');
    const toUpperCaseBtn = document.getElementById('toUpperCaseBtn');
    const avgSalaryBtn = document.getElementById('avgSalaryBtn');
    const avgSalaryResult = document.getElementById('avgSalaryResult');
    const searchedEmployeeResult = document.getElementById('searchedEmployeeResult');
    const employeeCount = document.getElementById('employeeCount');

    // ----- Core Modular Function to Render Table -----

    const renderTable = (employeeArray) => {
        employeeTableBody.innerHTML = ''; // Clear existing table rows

        // Use forEach to iterate over the employee array and create table rows.
        // forEach is great for executing a function for each array element without creating a new array,
        // making it perfect for DOM manipulation tasks like building this table.
        employeeArray.forEach(emp => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${emp.name}</td>
                <td>${emp.age}</td>
                <td>${emp.department}</td>
                <td>${emp.role}</td>
                <td>$${emp.salary.toLocaleString()}</td>
            `;
            employeeTableBody.appendChild(row);
        });
        
        // Update total employee count display
        employeeCount.textContent = employeeArray.length;
    };


    // ----- Functionalities & Event Listeners -----

    // Function to filter employees by department
    const filterByDepartment = () => {
        const selectedDepartment = departmentFilter.value;
        clearResults();

        // Use filter() to create a new array with employees from the selected department.
        // filter() is ideal for selectively displaying data based on a condition, which is
        // exactly what we need for the department dropdown.
        const filteredEmployees = selectedDepartment === 'all'
            ? employees
            : employees.filter(emp => emp.department === selectedDepartment);
        
        renderTable(filteredEmployees);
    };

    // Function to search employees by name
    const searchByName = () => {
        const searchTerm = searchInput.value.toLowerCase().trim();
        clearResults();

        if (!searchTerm) {
            searchedEmployeeResult.innerHTML = '';
            renderTable(employees); // Show all if search is cleared
            return;
        }

        // Use find() to search for the first employee whose name includes the search term.
        // find() is efficient for locating a single item in an array that matches a criterion,
        // making it suitable for a search feature that highlights one specific result.
        const foundEmployee = employees.find(emp => emp.name.toLowerCase().includes(searchTerm));

        if (foundEmployee) {
            searchedEmployeeResult.innerHTML = `
                <strong>Found Employee:</strong> 
                <p>${foundEmployee.name} - ${foundEmployee.role}, ${foundEmployee.department} (Salary: $${foundEmployee.salary.toLocaleString()})</p>
            `;
        } else {
             // Bonus: Validate search input
            searchedEmployeeResult.innerHTML = `<p>No match found.</p>`;
        }
        
        // Optionally, you could also filter the table to show matching results
        const matchingEmployees = employees.filter(emp => emp.name.toLowerCase().includes(searchTerm));
        renderTable(matchingEmployees);
    };

    // Function to convert names to uppercase
    const convertNamesToUppercase = () => {
        clearResults();

        // Use map() to create a new array where each employee's name is uppercased.
        // map() is used for transforming each element in an array into a new element,
        // perfect for tasks like formatting data without modifying the original source array.
        const updatedEmployees = employees.map(emp => {
            return { ...emp, name: emp.name.toUpperCase() };
        });

        renderTable(updatedEmployees);
    };

    // Function to calculate average salary
    const calculateAverageSalary = () => {
        clearResults();
        
        // Use reduce() to sum up all employee salaries into a single value (total).
        // reduce() is powerful for aggregating array data into one result, like a sum or average,
        // making it the best choice for calculating the total salary across all employees.
        const totalSalary = employees.reduce((accumulator, employee) => accumulator + employee.salary, 0);
        const averageSalary = totalSalary / employees.length;

        avgSalaryResult.textContent = `Average Salary: $${averageSalary.toFixed(2).toLocaleString()}`;
    };
    
    // Function to clear summary results
    const clearResults = () => {
        avgSalaryResult.textContent = '';
        searchedEmployeeResult.innerHTML = '';
    }

    // Bind event listeners to UI controls
    departmentFilter.addEventListener('change', filterByDepartment);
    searchInput.addEventListener('input', searchByName);
    toUpperCaseBtn.addEventListener('click', convertNamesToUppercase);
    avgSalaryBtn.addEventListener('click', calculateAverageSalary);

    // Initial table render on page load
    renderTable(employees);
});
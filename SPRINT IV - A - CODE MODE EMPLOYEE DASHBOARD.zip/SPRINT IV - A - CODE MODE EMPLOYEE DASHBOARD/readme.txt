Employee Management Dashboard Simulation

A responsive web dashboard for displaying and analyzing employee data. This project serves as a job simulation for a Front-End Development Intern role, focusing on vanilla JavaScript, HTML, and CSS.

Features

View Employees: Displays a full list of employees in a clean, sortable table.

Filter by Department: Allows users to filter the employee list by selecting a department from a dropdown menu.

Search by Name: Dynamically searches for an employee by name and displays their full details in a summary panel.

Calculate Average Salary: Calculates and displays the average salary of all employees with a single click.

Format Data: Converts all employee names to uppercase to demonstrate data transformation.

Responsive Design: The layout is fully responsive and works on desktop, tablet, and mobile devices.

Technology Stack

HTML5: For the core structure of the dashboard.

CSS3: For styling, layout, responsiveness, and hover transitions.

JavaScript: For all dynamic functionality, DOM manipulation, and data processing. The project heavily utilizes higher-order array methods:

forEach() to render the employee table.

map() to transform data (e.g., convert names to uppercase).

filter() to display employees by department.

reduce() to calculate the average salary.

find() to search for a specific employee.

How to Run

No special setup or build tools are required.

Place the three files (index.html, style.css, and script.js) in the same project folder.

Open the index.html file in any modern web browser (e.g., Google Chrome, Firefox, Microsoft Edge).

File Structure
Generated code
.
├── index.html     
├── style.css      
└── script.js      

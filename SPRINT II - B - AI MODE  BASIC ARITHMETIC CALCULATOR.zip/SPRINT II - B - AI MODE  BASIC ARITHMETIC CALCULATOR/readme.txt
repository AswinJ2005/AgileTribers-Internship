A feature-rich, modern calculator built with HTML, CSS, and vanilla JavaScript. It goes beyond basic arithmetic with features like voice commands, theme customization, and mobile-friendly gesture support.
✨ Features
🧮 Standard Arithmetic Operations: Includes all basic functions (+, -, *, /), percentages (%), and decimal support.
🎤 Voice Input: Use your voice to perform calculations. Simply click the microphone icon and say commands like "25 plus 10" or "clear". (Requires browser permission and is best supported on Chrome/Edge).
🎨 Theme Customization: Click the palette icon to choose from multiple pre-built themes (Dark, Light, Synthwave, Forest) to personalize your experience.
👆 Gesture Support: On touch devices, you can swipe left on the display area to delete the last character, just like a native mobile app.
📱 Responsive Design: A clean, modern interface that looks and works great on both desktop and mobile devices.
📳 Haptic Feedback: Subtle vibrations on button presses provide a more tactile experience on supported mobile devices.
💾 Persistent Settings: Your chosen theme is automatically saved in your browser's local storage and will be remembered on your next visit.
🚀 How to Use
Download the project files (index.html, style.css, script.js).
Make sure all three files are in the same folder.
Open the index.html file in your favorite web browser.
📂 File Structure
Generated code
/
├── index.html      # The main HTML structure
├── style.css       # All styles, themes, and animations
└── script.js       # Core logic, features, and event handling
Use code with caution.
🛠️ Technologies Used
HTML5
CSS3 (with CSS Variables for powerful theming)
JavaScript
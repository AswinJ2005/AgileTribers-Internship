document.addEventListener('DOMContentLoaded', function() {
    // --- DOM Elements ---
    const display = document.getElementById('display');
    const buttons = document.querySelector('.buttons');
    const body = document.body;
    const themeBtn = document.getElementById('theme-btn');
    const themeOptions = document.getElementById('theme-options');
    const voiceBtn = document.getElementById('voice-btn');

    // --- THEME CUSTOMIZATION ---
    function applyTheme(theme) {
        body.dataset.theme = theme;
        localStorage.setItem('theme', theme);
    }

    themeBtn.addEventListener('click', () => {
        themeOptions.classList.toggle('hidden');
    });

    themeOptions.addEventListener('click', (e) => {
        if (e.target.classList.contains('theme-option')) {
            const theme = e.target.dataset.theme;
            applyTheme(theme);
            themeOptions.classList.add('hidden');
        }
    });

    // Load saved theme on startup
    const savedTheme = localStorage.getItem('theme') || 'dark';
    applyTheme(savedTheme);

    // --- GESTURE SUPPORT (Swipe to Delete) ---
    let touchStartX = 0;
    let touchEndX = 0;

    display.parentElement.addEventListener('touchstart', (e) => {
        touchStartX = e.changedTouches[0].screenX;
    }, { passive: true });

    display.parentElement.addEventListener('touchend', (e) => {
        touchEndX = e.changedTouches[0].screenX;
        handleSwipe();
    });

    function handleSwipe() {
        // Swipe left with a minimum distance of 50px
        if (touchStartX - touchEndX > 50) {
            display.value = display.value.slice(0, -1);
            vibrate();
        }
    }
    
    // --- VOICE INPUT ---
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    let recognition;

    if (SpeechRecognition) {
        recognition = new SpeechRecognition();
        recognition.continuous = false;
        recognition.lang = 'en-US';

        voiceBtn.addEventListener('click', () => {
            body.classList.add('listening');
            recognition.start();
        });

        recognition.onresult = (event) => {
            const transcript = event.results[0][0].transcript.toLowerCase();
            processVoiceCommand(transcript);
        };

        recognition.onerror = (event) => {
            console.error('Speech recognition error:', event.error);
            body.classList.remove('listening');
        };
        
        recognition.onend = () => {
            body.classList.remove('listening');
        };
    } else {
        voiceBtn.style.display = 'none'; // Hide button if API not supported
    }

    function processVoiceCommand(command) {
        let processedCommand = command.replace(/x|times|multiply by/g, '*')
                                      .replace(/divided by|divide by/g, '/')
                                      .replace(/plus|add/g, '+')
                                      .replace(/minus|subtract/g, '-')
                                      .replace(/point/g, '.')
                                      .replace(/equals|calculate/g, '=')
                                      .replace(/clear|reset/g, 'AC')
                                      .replace(/delete|backspace/g, 'DEL')
                                      .replace(/\s+/g, ''); // Remove all spaces

        if (processedCommand === 'ac') {
            display.value = '';
        } else if (processedCommand === 'del') {
            display.value = display.value.slice(0, -1);
        } else if (processedCommand.endsWith('=')) {
            display.value = processedCommand.slice(0, -1);
            evaluateExpression();
        } else {
            display.value += processedCommand;
        }
    }

    // --- CALCULATOR CORE LOGIC ---
    function vibrate() {
        if (navigator.vibrate) navigator.vibrate(10);
    }
    
    function evaluateExpression() {
        try {
            let expression = display.value.replace(/x/g, '*').replace(/÷/g, '/');
            expression = expression.replace(/[%/*\-+]$/, ''); // Sanitize trailing operators
            let result = eval(expression);

            if (!isFinite(result) || isNaN(result)) {
                display.value = "Error";
            } else {
                display.value = Math.round(result * 1e12) / 1e12;
            }
        } catch (error) {
            display.value = 'Error';
        }
    }

    buttons.addEventListener('click', (e) => {
        if (e.target.matches('button')) {
            vibrate();
            const value = e.target.dataset.value;

            if (value === 'AC') {
                display.value = '';
            } else if (value === 'DEL') {
                display.value = display.value.slice(0, -1);
            } else if (value === '=') {
                evaluateExpression();
            } else {
                display.value += value;
            }
        }
    });
});
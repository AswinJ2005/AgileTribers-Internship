document.addEventListener('DOMContentLoaded', () => {

    const clockElement = document.getElementById('clock');
    const greetingElement = document.getElementById('greeting');

    function updateClock() {
        const now = new Date();

        let hours = now.getHours();
        const minutes = now.getMinutes();
        const seconds = now.getSeconds();

        let greeting;
        if (hours >= 6 && hours < 12) {
            greeting = "Good Morning";
        } else if (hours >= 12 && hours < 18) {
            greeting = "Good Afternoon";
        } else if (hours >= 18 && hours < 21) {
            greeting = "Good Evening";
        } else {
            greeting = "Good Night";
        }
        greetingElement.textContent = greeting;

        const ampm = hours >= 12 ? 'PM' : 'AM';
        hours = hours % 12;
        hours = hours ? hours : 12; 

        const formatTwoDigits = (num) => String(num).padStart(2, '0');

        const timeString = `${formatTwoDigits(hours)}:${formatTwoDigits(minutes)}:${formatTwoDigits(seconds)} ${ampm}`;

        clockElement.textContent = timeString;
    }

    updateClock();

    setInterval(updateClock, 1000);
});
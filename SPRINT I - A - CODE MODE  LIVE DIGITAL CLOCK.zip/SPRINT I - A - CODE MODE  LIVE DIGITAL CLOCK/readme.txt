Live Digital Clock

A simple, real-time digital clock built with HTML, CSS, and JavaScript. This project displays the current time and a dynamic, time-based greeting.

Features

Real-time updates every second.

12-hour format with AM/PM.

Dynamic greeting (e.g., "Good Morning").

Clean, readable UI.

How to Run

Download the project files (index.html, style.css, script.js).

Open index.html in any web browser.

Tech Stack: HTML, CSS, JavaScript